# Plano — Entregas MottuCoin

## Objetivo
Acrescentar o serviço de entregas sem remover ou alterar o conteúdo atual, mantendo o visual urbano, o site bilíngue e a experiência principal em uma página contínua.

## Nova área pública
- Adicionar a seção “Entregas MottuCoin — Feito por nós, para nós” com o motivo do projeto, cobertura atual em Rolândia-PR e região, expansão cidade por cidade e divisão transparente de 90% para o entregador e 10% para o projeto e queima.
- Incluir ações bem visíveis para “Pedir entrega”, “Sou entregador”, “Acompanhar pedido” e “Instalar app”.
- Traduzir toda a nova experiência para português e inglês, seguindo o seletor PT | EN já existente.

## Pedido e acompanhamento
- Criar o formulário de pedido com nome, telefone, cidade, retirada, entrega, item e pagamento por PIX ou $MOTTUCOIN.
- Como o entregador definirá o preço, o cliente não informa valor ao abrir o pedido; o valor aparece quando um entregador propõe e aceita.
- Gerar código e chave privada de acompanhamento após o envio, com orientação para o cliente guardar ambos.
- Mostrar a linha do tempo “Enviado → Aceito → A caminho → Entregue”, atualizada em tempo real e com avisos dentro do site.

## Área do entregador
- Adicionar cadastro com nome, telefone, cidade/região, veículo e disponibilidade.
- Oferecer entrada por e-mail/senha ou Google e manter os dados protegidos.
- Manter novos cadastros como “aguardando aprovação”; a aprovação será feita manualmente no painel do projeto.
- Para aprovados, exibir pedidos disponíveis de Rolândia e região, permitir informar o valor proposto, aceitar e avançar pelas etapas “A caminho” e “Entregue”.

## Instalação no celular
- Adicionar ícones e configuração para instalar o site na tela inicial como aplicativo, sem loja.
- Exibir “Instalar app” quando o navegador permitir e instruções adequadas quando a instalação automática não estiver disponível.
- Não adicionar modo offline nesta etapa; pedidos e acompanhamento precisam de internet para manter os dados atualizados.

## Segurança e dados
- Validar todos os campos no navegador e no servidor.
- Guardar pedidos, cadastros e eventos no Lovable Cloud com acesso restrito: clientes somente por código + chave, e entregadores somente após aprovação.
- Impedir que mudanças de status, valor ou entregador sejam feitas fora da ordem correta.

## Verificação
- Testar pedido completo, código de acompanhamento, cadastro/login, bloqueio de entregador pendente e fluxo de atualização.
- Conferir instalação, português/inglês e telas de computador e celular.
