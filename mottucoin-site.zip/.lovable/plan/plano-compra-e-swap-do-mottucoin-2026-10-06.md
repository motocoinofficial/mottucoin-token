# Plano — Compra e swap do MottuCoin

## Objetivo
Ampliar a área de mercado existente com uma seção clara para acompanhar e comprar $MOTTU, sem remover nenhuma parte do site.

## O que será adicionado
- Painel de preço do $MOTTU com atualização automática e indicação de variação em 24 horas.
- Identificação visível do token, usando o ícone M oficial e o contrato completo da Solana.
- Ações diretas para comprar na Pump.fun e fazer swap pela Jupiter.
- Links de verificação para Solscan, Pump.fun, Birdeye e DexScreener.
- Manter o gráfico ao vivo e as instruções de compra em três passos já existentes.
- Todo o novo conteúdo em português e inglês, acompanhando o seletor PT | EN atual.

## Visual
- Preservar a identidade urbana escura, verde e preta.
- Manter leitura compacta e clara no celular e no computador.

## Detalhes técnicos
- Consultar preço e variação pública pelo DexScreener no navegador, com estado de indisponibilidade caso o mercado ainda não retorne dados.
- Abrir compra, swap e verificadores em páginas oficiais externas, sem custodiar carteira ou fundos no site.
- Não alterar entregas, comunidade, tokenomics ou qualquer outro fluxo existente.
