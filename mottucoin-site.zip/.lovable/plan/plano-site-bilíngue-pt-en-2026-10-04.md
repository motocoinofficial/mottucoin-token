# Plano — Site bilíngue PT/EN

## Objetivo
Adicionar inglês sem remover o português, mantendo exatamente o mesmo visual e a mesma página única.

## Implementação
- Centralizar todo o conteúdo visível em versões PT-BR e EN, incluindo navegação, títulos, botões, descrições, perguntas frequentes, avisos e textos alternativos das imagens.
- Adicionar um seletor `PT | EN` bem visível no cabeçalho para computador e celular.
- Abrir em português na primeira visita e salvar a escolha no navegador para visitas futuras.
- Atualizar o idioma do documento e o título/descrição da página quando a opção mudar.
- Preservar todos os links, imagens, seções, interações e o estilo urbano escuro com verde.

## Verificação
- Conferir a troca completa de idioma e a persistência da escolha.
- Validar o site em computador e celular, incluindo o menu móvel e a cópia do contrato.
