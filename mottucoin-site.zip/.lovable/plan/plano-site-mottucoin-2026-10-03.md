# Plano — Site MottuCoin

## Objetivo
Criar a página oficial da MottuCoin em português, com foco em confiança, transparência e compra simples para entregadores.

## Página
- Abrir com a identidade MottuCoin, a proposta “feito por entregadores” e ações para comprar ou verificar o contrato.
- Usar as fotos enviadas em uma direção urbana, noturna e energética, priorizando leitura no celular.
- Organizar contrato, links oficiais, segurança, tokenomics, programa de queima e espaço para o gráfico ao vivo.
- Explicar a compra em três passos, incluindo Phantom, SOL, PIX e o link oficial da Pump.fun.
- Apresentar cashback, roadmap, perguntas frequentes, comunidade e avisos legais.
- Criar botões funcionais para copiar o contrato, abrir plataformas e navegar entre seções.

## Direção visual
- Fundo carvão, verde elétrico e amarelo de sinalização, com tipografia forte e utilitária.
- Fotos reais como elementos dominantes, com linhas e etiquetas inspiradas em sinalização urbana.
- Layout compacto, direto e acessível, sem aparência genérica de site de criptomoeda.

## Detalhes técnicos
- Página única em React/TanStack, sem cadastro ou banco de dados.
- Imagens enviadas hospedadas como ativos do projeto.
- Conteúdo adaptável a celular e computador, com metadados próprios para compartilhamento.
- O gráfico terá acesso direto ao DexScreener; incorporação será usada somente se a plataforma permitir exibição segura no navegador.
- Links ainda não fornecidos serão mostrados como pendentes, sem inventar destinos.
