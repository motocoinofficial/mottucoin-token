import { inspectTrade, PUMP_PROGRAMS, type ChainTransaction } from "./community-chain";

export async function solanaRpc<T>(method: string, params: unknown[]): Promise<T> {
  const response = await fetch("https://api.mainnet-beta.solana.com", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }), signal: AbortSignal.timeout(15_000),
  });
  if (!response.ok) throw new Error("A rede Solana está indisponível. Tente novamente.");
  const body = await response.json() as { result?: T; error?: unknown };
  if (body.error || body.result === undefined) throw new Error("Não foi possível confirmar os dados na Solana.");
  return body.result;
}

export async function getTransaction(signature: string) {
  const tx = await solanaRpc<ChainTransaction | null>("getTransaction", [signature, { encoding: "jsonParsed", commitment: "finalized", maxSupportedTransactionVersion: 0 }]);
  if (!tx) throw new Error("Transação não encontrada ou ainda não confirmada.");
  return tx;
}

// Only SOL paid directly by the buyer to accounts owned by an approved market
// is valued. Gifts, self-transfers, rent, network fees and unrelated programs do not qualify.
export async function verifyPurchase(signature: string, wallet: string) {
  const tx = await getTransaction(signature);
  const trade = inspectTrade(tx, wallet);
  if (!trade || trade.kind !== "buy") throw new Error("Não encontramos uma compra $MOTTU elegível nesta carteira.");
  const instructions = [...tx.transaction.message.instructions, ...(tx.meta?.innerInstructions ?? []).flatMap((i) => i.instructions)];
  const transfers = instructions.filter((i) => i.programId === "11111111111111111111111111111111" && i.parsed?.type === "transfer" && i.parsed.info?.source === wallet);
  let lamports = 0;
  for (const instruction of transfers) {
    const info = instruction.parsed?.info;
    if (!info?.destination || !info.lamports) continue;
    const account = await solanaRpc<{ value: { owner: string } | null }>("getAccountInfo", [info.destination, { encoding: "base64", commitment: "finalized" }]);
    if (account.value && PUMP_PROGRAMS.includes(account.value.owner)) lamports += info.lamports;
  }
  if (lamports <= 0) throw new Error("Esta compra não pôde ser avaliada com segurança. Use uma compra em SOL na Pump.fun.");
  const response = await fetch(`https://coins.llama.fi/prices/historical/${trade.at}/coingecko:solana`, { signal: AbortSignal.timeout(10_000) });
  if (!response.ok) throw new Error("Cotação histórica indisponível. Tente novamente.");
  const prices = await response.json() as { coins?: Record<string, { price: number; timestamp: number; confidence?: number }> };
  const price = prices.coins?.["coingecko:solana"];
  if (!price || !Number.isFinite(price.price) || price.price <= 0 || Math.abs(price.timestamp - trade.at) > 3600 || (price.confidence ?? 0) < 0.9) throw new Error("Cotação histórica não confirmada.");
  return { usd: lamports / 1e9 * price.price, tokens: trade.tokens, at: new Date(trade.at * 1000).toISOString() };
}

type HistoryRow = { signature: string; blockTime: number | null; err: unknown };
export async function inspectSellWindow(wallet: string, start: string, end: string) {
  const from = Date.parse(start) / 1000, until = Date.parse(end) / 1000;
  let before: string | undefined;
  // Never release if the complete window cannot be inspected or the RPC fails.
  for (let page = 0; page < 10; page++) {
    const rows = await solanaRpc<HistoryRow[]>("getSignaturesForAddress", [wallet, { limit: 100, before, commitment: "finalized" }]);
    for (const row of rows) {
      if (row.err) continue;
      if (row.blockTime === null) throw new Error("Histórico incompleto. Comissão permanece pendente.");
      if (row.blockTime < from) return false;
      if (row.blockTime >= until) continue;
      const trade = inspectTrade(await getTransaction(row.signature), wallet);
      if (trade?.kind === "sell") return true;
    }
    if (rows.length < 100) return false;
    before = rows.at(-1)?.signature;
  }
  throw new Error("Histórico extenso. Comissão permanece pendente para verificação.");
}

export async function settleMemberCommissions(memberId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: commissions, error } = await supabaseAdmin.from("community_commissions").select("id, source_member_id, qualifying_purchase_at, sell_lock_until, hold_until").eq("beneficiary_id", memberId).eq("status", "pending");
  if (error) throw new Error("Não foi possível atualizar as comissões.");
  let checked = 0;
  for (const row of commissions ?? []) {
    const { data: member } = await supabaseAdmin.from("community_members").select("solana_wallet, wallet_verified_at").eq("id", row.source_member_id).single();
    if (!member?.solana_wallet || !member.wallet_verified_at) continue;
    try {
      const sold = await inspectSellWindow(member.solana_wallet, row.qualifying_purchase_at, row.sell_lock_until);
      if (sold) {
        const result = await supabaseAdmin.from("community_commissions").update({ status: "forfeited", forfeiture_reason: "sale_before_15_days" }).eq("id", row.id).eq("status", "pending");
        if (result.error) throw result.error;
      } else if (Date.parse(row.hold_until) <= Date.now()) {
        const result = await supabaseAdmin.from("community_commissions").update({ status: "available" }).eq("id", row.id).eq("status", "pending");
        if (result.error) throw result.error;
      }
      checked++;
    } catch { /* Fail closed: RPC uncertainty can never release a commission. */ }
  }
  return { checked, pending: (commissions?.length ?? 0) - checked };
}