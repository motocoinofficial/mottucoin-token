export const MOTTU_CONTRACT = "BqV5L1apSdYjKEAa54qS9WCQdoSwpaNjcFYvBGoVpump";
export const PUMP_PROGRAMS = ["6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P", "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA"];

type TokenBalance = { mint: string; owner?: string; uiTokenAmount: { amount: string; decimals: number } };
type Instruction = { programId?: string; parsed?: { type?: string; info?: { source?: string; destination?: string; lamports?: number } } };
export type ChainTransaction = {
  blockTime: number | null;
  meta: { err: unknown; logMessages?: string[]; preTokenBalances?: TokenBalance[]; postTokenBalances?: TokenBalance[]; innerInstructions?: { instructions: Instruction[] }[] } | null;
  transaction: { message: { accountKeys: { pubkey: string; signer: boolean }[]; instructions: Instruction[] } };
};

export function inspectTrade(tx: ChainTransaction, wallet: string) {
  if (!tx.meta || tx.meta.err || !tx.blockTime || !tx.transaction.message.accountKeys.some((key) => key.pubkey === wallet && key.signer)) return null;
  const invoked = tx.meta.logMessages?.some((line) => PUMP_PROGRAMS.some((id) => line.startsWith(`Program ${id} invoke`)));
  if (!invoked) return null;
  const total = (balances: TokenBalance[] = []) => balances.filter((b) => b.mint === MOTTU_CONTRACT && b.owner === wallet).reduce((sum, b) => sum + Number(b.uiTokenAmount.amount) / 10 ** b.uiTokenAmount.decimals, 0);
  const delta = total(tx.meta.postTokenBalances) - total(tx.meta.preTokenBalances);
  const logs = tx.meta.logMessages ?? [];
  const buy = logs.some((line) => /^Program log: Instruction: Buy(?:ExactSolIn|ExactQuoteIn)?$/.test(line));
  const sell = logs.includes("Program log: Instruction: Sell");
  if (delta > 0 && buy && !sell) return { kind: "buy" as const, tokens: delta, at: tx.blockTime };
  if (delta < 0 && sell && !buy) return { kind: "sell" as const, tokens: -delta, at: tx.blockTime };
  return null;
}