import { createServerFn } from "@tanstack/react-start";
import { createHash, randomBytes } from "crypto";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const text = (min: number, max: number) => z.string().trim().min(min).max(max);
const phone = z.string().trim().regex(/^[0-9+()\-\s]{8,20}$/);

const orderSchema = z.object({
  customerName: text(2, 100),
  customerPhone: phone,
  city: text(2, 100),
  pickupAddress: text(5, 300),
  deliveryAddress: text(5, 300),
  itemDescription: text(2, 500),
  paymentMethod: z.enum(["pix", "mottucoin"]),
});

const trackingSchema = z.object({
  code: z.string().trim().toUpperCase().regex(/^[A-F0-9]{10}$/),
  secret: z.string().trim().regex(/^[a-f0-9]{32}$/),
});

const riderSchema = z.object({
  name: text(2, 100),
  phone,
  cityRegion: text(2, 120),
  vehicle: text(2, 80),
  availability: text(2, 200),
});

const hashSecret = (secret: string) => createHash("sha256").update(secret).digest("hex");

export const createDeliveryOrder = createServerFn({ method: "POST" })
  .inputValidator((input) => orderSchema.parse(input))
  .handler(async ({ data }) => {
    const secret = randomBytes(16).toString("hex");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: order, error } = await supabaseAdmin.from("delivery_orders").insert({
      customer_name: data.customerName,
      customer_phone: data.customerPhone,
      city: data.city,
      pickup_address: data.pickupAddress,
      delivery_address: data.deliveryAddress,
      item_description: data.itemDescription,
      payment_method: data.paymentMethod,
      tracking_secret_hash: hashSecret(secret),
    }).select("id, tracking_code, status, created_at").single();
    if (error || !order) throw new Error("Não foi possível enviar o pedido.");
    await supabaseAdmin.from("delivery_events").insert({
      order_id: order.id,
      status: "sent",
      message_pt: "Pedido enviado para os entregadores aprovados.",
      message_en: "Order sent to approved delivery riders.",
    });
    return { code: order.tracking_code, secret, status: order.status, createdAt: order.created_at };
  });

export const trackDeliveryOrder = createServerFn({ method: "POST" })
  .inputValidator((input) => trackingSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: order, error } = await supabaseAdmin.from("delivery_orders")
      .select("id, tracking_code, city, pickup_address, delivery_address, item_description, payment_method, proposed_amount, status, rider_name, created_at, updated_at")
      .eq("tracking_code", data.code).eq("tracking_secret_hash", hashSecret(data.secret)).maybeSingle();
    if (error || !order) throw new Error("Código ou chave de acompanhamento inválidos.");
    const { data: events } = await supabaseAdmin.from("delivery_events")
      .select("id, status, message_pt, message_en, created_at").eq("order_id", order.id).order("created_at");
    return { order, events: events ?? [] };
  });

export const submitRiderApplication = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => riderSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("rider_applications").insert({
      user_id: context.userId,
      name: data.name,
      phone: data.phone,
      city_region: data.cityRegion,
      vehicle: data.vehicle,
      availability: data.availability,
    });
    if (error) throw new Error(error.code === "23505" ? "Seu cadastro já foi enviado." : "Não foi possível enviar seu cadastro.");
    return { ok: true };
  });

export const getRiderDashboard = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: application } = await context.supabase.from("rider_applications")
      .select("name, city_region, approval_status").eq("user_id", context.userId).maybeSingle();
    if (!application) return { application: null, orders: [] };
    if (application.approval_status !== "approved") return { application, orders: [] };
    const { data: orders, error } = await context.supabase.from("delivery_orders")
      .select("id, tracking_code, city, pickup_address, delivery_address, item_description, payment_method, proposed_amount, status, rider_id, created_at")
      .or(`status.eq.sent,rider_id.eq.${context.userId}`).order("created_at", { ascending: false });
    if (error) throw new Error("Não foi possível carregar os pedidos.");
    return { application, orders: orders ?? [] };
  });

export const acceptDeliveryOrder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ orderId: z.string().uuid(), proposedAmount: z.number().positive().max(999999.99) }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: rider } = await context.supabase.from("rider_applications")
      .select("name, approval_status").eq("user_id", context.userId).single();
    if (!rider || rider.approval_status !== "approved") throw new Error("Seu cadastro ainda não foi aprovado.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: order, error } = await supabaseAdmin.from("delivery_orders").update({
      rider_id: context.userId, rider_name: rider.name, proposed_amount: data.proposedAmount, status: "accepted", accepted_at: new Date().toISOString(),
    }).eq("id", data.orderId).eq("status", "sent").is("rider_id", null).select("id").maybeSingle();
    if (error || !order) throw new Error("Este pedido já foi aceito por outro entregador.");
    await supabaseAdmin.from("delivery_events").insert({ order_id: order.id, status: "accepted", message_pt: "Pedido aceito. O valor da entrega foi informado.", message_en: "Order accepted. The delivery price is now available." });
    return { ok: true };
  });

export const advanceDeliveryOrder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ orderId: z.string().uuid(), nextStatus: z.enum(["on_the_way", "delivered"]) }).parse(input))
  .handler(async ({ data, context }) => {
    const expected = data.nextStatus === "on_the_way" ? "accepted" : "on_the_way";
    const timestamp = new Date().toISOString();
    const updates = data.nextStatus === "on_the_way" ? { status: data.nextStatus, on_the_way_at: timestamp } : { status: data.nextStatus, delivered_at: timestamp };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: order, error } = await supabaseAdmin.from("delivery_orders").update(updates)
      .eq("id", data.orderId).eq("rider_id", context.userId).eq("status", expected).select("id").maybeSingle();
    if (error || !order) throw new Error("Esta etapa não pode ser atualizada agora.");
    await supabaseAdmin.from("delivery_events").insert({
      order_id: order.id, status: data.nextStatus,
      message_pt: data.nextStatus === "on_the_way" ? "O entregador está a caminho." : "Entrega concluída.",
      message_en: data.nextStatus === "on_the_way" ? "The delivery rider is on the way." : "Delivery completed.",
    });
    return { ok: true };
  });