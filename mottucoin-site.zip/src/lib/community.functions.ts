import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { createHash, randomBytes } from "crypto";
import { z } from "zod";
import { ed25519 } from "@noble/curves/ed25519.js";
import bs58 from "bs58";

const RULES_VERSION = "2026-10-06";
const referralCode = z.string().trim().toUpperCase().regex(/^[A-F0-9]{10}$/);
const deviceId = z.string().trim().min(16).max(120);
const accessSecret = z.string().trim().regex(/^[a-f0-9]{64}$/);
const wallet = z.string().trim().regex(/^[1-9A-HJ-NP-Za-km-z]{32,44}$/);

function hash(value: string) {
  const pepper = process.env['COMMUNITY_HASH_PEPPER'];
  if (!pepper) throw new Error("Configuração da comunidade indisponível.");
  return createHash("sha256").update(`${pepper}:${value}`).digest("hex");
}

function requestIp() {
  const forwarded = getRequestHeader("cf-connecting-ip") ?? getRequestHeader("x-forwarded-for") ?? getRequestHeader("x-real-ip");
  return forwarded?.split(",")[0]?.trim() || "unknown";
}

export const registerReferralVisit = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ code: referralCode, deviceId }).parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: referrer } = await supabaseAdmin.from("community_members")
      .select("id").eq("referral_code", data.code).maybeSingle();
    if (!referrer) return { valid: false };

    const deviceHash = hash(data.deviceId);
    const ipHash = hash(requestIp());
    const [{ data: sameDevice }, { data: sameIp }] = await Promise.all([
      supabaseAdmin.from("community_members").select("id").eq("device_hash", deviceHash).maybeSingle(),
      supabaseAdmin.from("community_members").select("id").eq("ip_hash", ipHash).maybeSingle(),
    ]);
    const eligible = !sameDevice && !sameIp;
    await supabaseAdmin.from("community_referral_visits").insert({
      referrer_id: referrer.id,
      referral_code: data.code,
      device_hash: deviceHash,
      ip_hash: ipHash,
      eligible,
      ineligible_reason: sameDevice ? "same_device" : sameIp ? "same_ip" : null,
    });
    return { valid: true, eligible };
  });

export const joinCommunity = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({
    deviceId,
    referralCode: referralCode.optional(),
    acceptedRules: z.literal(true),
  }).parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const deviceHash = hash(data.deviceId);
    const ipHash = hash(requestIp());
    const [{ data: sameDevice }, { data: sameIp }] = await Promise.all([
      supabaseAdmin.from("community_members").select("id").eq("device_hash", deviceHash).maybeSingle(),
      supabaseAdmin.from("community_members").select("id").eq("ip_hash", ipHash).maybeSingle(),
    ]);
    if (sameDevice || sameIp) throw new Error("Este dispositivo ou conexão já participa da comunidade.");

    let referrer: { id: string; referred_by: string | null } | null = null;
    if (data.referralCode) {
      const result = await supabaseAdmin.from("community_members")
        .select("id, referred_by").eq("referral_code", data.referralCode).maybeSingle();
      referrer = result.data;
    }

    const secret = randomBytes(32).toString("hex");
    const { data: member, error } = await supabaseAdmin.from("community_members").insert({
      access_secret_hash: hash(secret),
      referred_by: referrer?.id ?? null,
      network_referrer_id: referrer?.referred_by ?? null,
      rules_version: RULES_VERSION,
      rules_accepted_at: new Date().toISOString(),
      device_hash: deviceHash,
      ip_hash: ipHash,
    }).select("id, referral_code, rules_accepted_at").single();
    if (error || !member) throw new Error("Não foi possível liberar seu acesso agora.");

    if (data.referralCode && referrer) {
      await supabaseAdmin.from("community_referral_visits").update({ converted_member_id: member.id })
        .eq("referral_code", data.referralCode).eq("device_hash", deviceHash).is("converted_member_id", null);
    }
    return { secret, member: { code: member.referral_code, acceptedAt: member.rules_accepted_at } };
  });

export const getCommunityDashboard = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ secret: accessSecret }).parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: member } = await supabaseAdmin.from("community_members")
      .select("id, referral_code, rules_accepted_at, solana_wallet, wallet_verified_at").eq("access_secret_hash", hash(data.secret)).maybeSingle();
    if (!member) throw new Error("Acesso da comunidade não encontrado neste aparelho.");

    const { settleMemberCommissions } = await import("./community-chain.server");
    await settleMemberCommissions(member.id);

    const monthStart = new Date();
    monthStart.setUTCDate(1); monthStart.setUTCHours(0, 0, 0, 0);
    const [{ count: directCount }, { count: networkCount }, { data: commissions }] = await Promise.all([
      supabaseAdmin.from("community_members").select("id", { count: "exact", head: true }).eq("referred_by", member.id),
      supabaseAdmin.from("community_members").select("id", { count: "exact", head: true }).eq("network_referrer_id", member.id),
      supabaseAdmin.from("community_commissions").select("id, commission_usd, mottu_amount, status, hold_until, qualifying_purchase_at, referral_level, source_reference")
        .eq("beneficiary_id", member.id).order("qualifying_purchase_at", { ascending: false }),
    ]);
    const rows = commissions ?? [];
    return {
      code: member.referral_code,
      acceptedAt: member.rules_accepted_at,
      wallet: member.solana_wallet,
      walletVerified: Boolean(member.wallet_verified_at),
      directCount: directCount ?? 0,
      networkCount: networkCount ?? 0,
      monthUsd: rows.filter((row) => row.qualifying_purchase_at >= monthStart.toISOString()).reduce((sum, row) => sum + Number(row.commission_usd), 0),
      pendingMottu: rows.filter((row) => row.status === "pending").reduce((sum, row) => sum + Number(row.mottu_amount), 0),
      availableMottu: rows.filter((row) => row.status === "available").reduce((sum, row) => sum + Number(row.mottu_amount), 0),
      nextRelease: rows.filter((row) => row.status === "pending").map((row) => row.hold_until).sort()[0] ?? null,
      commissions: rows.map((row) => ({ id: row.id, usd: Number(row.commission_usd), tokens: Number(row.mottu_amount), status: row.status, releaseAt: row.hold_until, level: row.referral_level, signature: row.source_reference })),
    };
  });

export const createWalletChallenge = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ secret: accessSecret, wallet }).parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    if (bs58.decode(data.wallet).length !== 32) throw new Error("Carteira inválida.");
    const { data: member } = await supabaseAdmin.from("community_members").select("id").eq("access_secret_hash", hash(data.secret)).maybeSingle();
    if (!member) throw new Error("Acesso inválido.");
    const expiresAt = new Date(Date.now() + 5 * 60_000).toISOString();
    const message = `MottuCoin Community — wallet confirmation\nWallet: ${data.wallet}\nMember: ${member.id}\nNonce: ${randomBytes(32).toString("hex")}\nExpires: ${expiresAt}\nThis signature confirms wallet ownership only. No transaction or token approval.`;
    const { data: challenge, error } = await supabaseAdmin.from("community_wallet_challenges").insert({ member_id: member.id, wallet: data.wallet, message, expires_at: expiresAt }).select("id").single();
    if (error || !challenge) throw new Error("Não foi possível confirmar a carteira.");
    return { id: challenge.id, message };
  });

export const confirmCommunityWallet = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ secret: accessSecret, challengeId: z.string().uuid(), signature: z.array(z.number().int().min(0).max(255)).length(64) }).parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: member } = await supabaseAdmin.from("community_members").select("id").eq("access_secret_hash", hash(data.secret)).maybeSingle();
    if (!member) throw new Error("Acesso inválido.");
    const { data: challenge } = await supabaseAdmin.from("community_wallet_challenges").select("wallet, message, expires_at, used_at").eq("id", data.challengeId).eq("member_id", member.id).maybeSingle();
    if (!challenge || challenge.used_at || Date.parse(challenge.expires_at) <= Date.now()) throw new Error("Confirmação expirada. Tente novamente.");
    if (!ed25519.verify(Uint8Array.from(data.signature), new TextEncoder().encode(challenge.message), bs58.decode(challenge.wallet), { zip215: false })) throw new Error("Assinatura inválida.");
    const { error } = await supabaseAdmin.rpc("confirm_community_wallet", { p_member: member.id, p_challenge: data.challengeId });
    if (error) throw new Error("Esta carteira já está em uso ou vinculada ao histórico de compras.");
    return { ok: true };
  });

export const confirmCommunityPurchase = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ secret: accessSecret, signature: z.string().trim().regex(/^[1-9A-HJ-NP-Za-km-z]{80,90}$/) }).parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: member } = await supabaseAdmin.from("community_members").select("id, solana_wallet, wallet_verified_at").eq("access_secret_hash", hash(data.secret)).maybeSingle();
    if (!member?.solana_wallet || !member.wallet_verified_at) throw new Error("Confirme sua carteira primeiro.");
    const { verifyPurchase } = await import("./community-chain.server");
    const purchase = await verifyPurchase(data.signature, member.solana_wallet);
    const { data: count, error } = await supabaseAdmin.rpc("record_community_purchase", { p_member: member.id, p_signature: data.signature, p_usd: purchase.usd, p_tokens: purchase.tokens, p_at: purchase.at });
    if (error) throw new Error("A compra deve ocorrer após a confirmação da carteira e a entrada na comunidade.");
    return { recorded: count ?? 0 };
  });