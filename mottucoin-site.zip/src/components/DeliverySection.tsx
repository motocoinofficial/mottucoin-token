import { useEffect, useState, type FormEvent } from "react";
import { useServerFn } from "@tanstack/react-start";
import { z } from "zod";
import {
  ArrowRight,
  Bell,
  Bike,
  Check,
  CircleDollarSign,
  Clock3,
  Copy,
  Download,
  LogIn,
  MapPin,
  PackageCheck,
  Route,
  Send,
  ShieldCheck,
  Smartphone,
  Store,
  UserRoundCheck,
} from "lucide-react";

import { lovable } from "@/integrations/lovable";
import { supabase } from "@/integrations/supabase/client";
import {
  acceptDeliveryOrder,
  advanceDeliveryOrder,
  createDeliveryOrder,
  getRiderDashboard,
  submitRiderApplication,
  trackDeliveryOrder,
} from "@/lib/deliveries.functions";

type Language = "pt" | "en";
type Panel = "order" | "track" | "rider";
type TrackingResult = Awaited<ReturnType<typeof trackDeliveryOrder>>;
type RiderResult = Awaited<ReturnType<typeof getRiderDashboard>>;

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

const field = z.string().trim().min(2).max(300);
const orderSchema = z.object({
  customerName: z.string().trim().min(2).max(100),
  customerPhone: z.string().trim().regex(/^[0-9+()\-\s]{8,20}$/),
  city: z.string().trim().min(2).max(100),
  pickupAddress: field,
  deliveryAddress: field,
  itemDescription: z.string().trim().min(2).max(500),
  paymentMethod: z.enum(["pix", "mottucoin"]),
});

const copy = {
  pt: {
    eyebrow: "Entregas MottuCoin", titleA: "Feito por nós.", titleB: "Para nós.",
    intro: "Todo mundo já viu: um motoboy daqui fez, deu certo e conquistou clientes do iFood. Aqui o comércio paga uma taxa justa e quem trabalha recebe de verdade.",
    why: "Por que nós?", whyText: "O iFood cobra caro do comércio e repassa pouco para quem trabalha. Aqui é diferente: a comunidade cresce junto.",
    now: "Agora", nowText: "Rolândia-PR e região", soon: "Em breve", soonText: "Todo o Brasil — cidade por cidade",
    client: "Cliente", clientText: "Informa retirada, destino, o que levar e a forma de pagamento.",
    rider: "Entregador", riderText: "Recebe o pedido, propõe o valor, aceita, entrega e recebe.",
    fair: "Taxa justa", fairText: "90% fica com o entregador. 10% fortalece o projeto e a queima de tokens.",
    transparency: "O valor fortalece o token e a queima — não vai para o bolso de ninguém. Tudo é transparente com a comunidade.",
    orderTab: "Pedir entrega", trackTab: "Acompanhar", riderTab: "Sou entregador", install: "Instalar app",
    coverage: "Atendemos Rolândia-PR e região", name: "Nome", phone: "Telefone", city: "Cidade", pickup: "Endereço de retirada", dropoff: "Endereço de entrega", item: "O que levar", payment: "Forma de pagamento", send: "Enviar pedido", sending: "Enviando...",
    riderPrices: "O entregador propõe o valor antes de aceitar o pedido.", orderReady: "Pedido enviado! Guarde estes dados para acompanhar:", code: "Código", secret: "Chave privada", saveWarning: "Salve a chave agora. Por segurança, ela não será exibida novamente.", copyData: "Copiar dados", copied: "Copiado",
    trackHelp: "Use o código e a chave privada recebidos ao enviar o pedido.", track: "Acompanhar pedido", updating: "Buscando...", invalid: "Confira os campos e tente novamente.",
    statuses: { sent: "Enviado", accepted: "Aceito", on_the_way: "A caminho", delivered: "Entregue" },
    price: "Valor proposto", waitingPrice: "Aguardando proposta do entregador", riderName: "Entregador", notifications: "As atualizações aparecem automaticamente enquanto esta tela estiver aberta.",
    authTitle: "Área do entregador", email: "E-mail", password: "Senha", signIn: "Entrar", signUp: "Criar conta", google: "Continuar com Google", signOut: "Sair", authHint: "Entre para enviar seu cadastro e acessar pedidos após aprovação.",
    applyTitle: "Cadastro de entregador", region: "Cidade / região", vehicle: "Veículo", availability: "Disponibilidade", apply: "Enviar cadastro", applyHint: "Seja o primeiro da sua cidade — abrimos conforme crescemos!", pending: "Cadastro recebido. Aguardando aprovação manual.", rejected: "Cadastro não aprovado. Fale com a comunidade para revisar seus dados.", approved: "Cadastro aprovado", noOrders: "Nenhum pedido disponível agora.", available: "Pedidos disponíveis", proposal: "Sua proposta em R$", accept: "Propor e aceitar", onWay: "Marcar a caminho", delivered: "Marcar entregue", installIos: "No iPhone, toque em Compartilhar e depois em Adicionar à Tela de Início.", installUnavailable: "Use o menu do navegador e escolha Instalar aplicativo ou Adicionar à tela inicial.", installed: "O app já está instalado neste aparelho.",
  },
  en: {
    eyebrow: "MottuCoin Deliveries", titleA: "Made by us.", titleB: "For us.",
    intro: "Everyone has seen it: a local delivery rider made it work and won over iFood customers. Here, businesses pay a fair fee and workers receive what they deserve.",
    why: "Why us?", whyText: "iFood charges businesses a lot and pays workers too little. Here it is different: the whole community grows together.",
    now: "Now", nowText: "Rolândia, Paraná and nearby areas", soon: "Coming soon", soonText: "All of Brazil — one city at a time",
    client: "Customer", clientText: "Provides pickup, destination, item details, and payment method.",
    rider: "Delivery rider", riderText: "Receives the order, proposes a price, accepts, delivers, and gets paid.",
    fair: "Fair fee", fairText: "90% stays with the rider. 10% strengthens the project and token burn.",
    transparency: "The value strengthens the token and its burn — it does not go into anyone's pocket. Everything is transparent with the community.",
    orderTab: "Request delivery", trackTab: "Track order", riderTab: "I'm a rider", install: "Install app",
    coverage: "Serving Rolândia, Paraná and nearby areas", name: "Name", phone: "Phone", city: "City", pickup: "Pickup address", dropoff: "Delivery address", item: "What to carry", payment: "Payment method", send: "Send order", sending: "Sending...",
    riderPrices: "The delivery rider proposes a price before accepting the order.", orderReady: "Order sent! Save these details to track it:", code: "Code", secret: "Private key", saveWarning: "Save this key now. For security, it will not be shown again.", copyData: "Copy details", copied: "Copied",
    trackHelp: "Use the code and private key received when you sent the order.", track: "Track order", updating: "Checking...", invalid: "Check the fields and try again.",
    statuses: { sent: "Sent", accepted: "Accepted", on_the_way: "On the way", delivered: "Delivered" },
    price: "Proposed price", waitingPrice: "Waiting for the rider's proposal", riderName: "Delivery rider", notifications: "Updates appear automatically while this screen is open.",
    authTitle: "Rider area", email: "Email", password: "Password", signIn: "Sign in", signUp: "Create account", google: "Continue with Google", signOut: "Sign out", authHint: "Sign in to apply and access orders after approval.",
    applyTitle: "Rider application", region: "City / region", vehicle: "Vehicle", availability: "Availability", apply: "Send application", applyHint: "Be the first in your city — we open as we grow!", pending: "Application received. Waiting for manual approval.", rejected: "Application not approved. Contact the community to review your details.", approved: "Application approved", noOrders: "No orders available right now.", available: "Available orders", proposal: "Your proposal in BRL", accept: "Propose and accept", onWay: "Mark on the way", delivered: "Mark delivered", installIos: "On iPhone, tap Share and then Add to Home Screen.", installUnavailable: "Use your browser menu and choose Install app or Add to Home Screen.", installed: "The app is already installed on this device.",
  },
} as const;

const inputClass = "min-h-12 w-full border border-border bg-background px-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary";

export function DeliverySection({ language }: { language: Language }) {
  const t = copy[language];
  const [panel, setPanel] = useState<Panel>("order");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [credentials, setCredentials] = useState<{ code: string; secret: string } | null>(null);
  const [tracking, setTracking] = useState<TrackingResult | null>(null);
  const [trackingInput, setTrackingInput] = useState({ code: "", secret: "" });
  const [sessionUser, setSessionUser] = useState<string | null>(null);
  const [dashboard, setDashboard] = useState<RiderResult | null>(null);
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);

  const createOrder = useServerFn(createDeliveryOrder);
  const trackOrder = useServerFn(trackDeliveryOrder);
  const sendApplication = useServerFn(submitRiderApplication);
  const loadDashboard = useServerFn(getRiderDashboard);
  const acceptOrder = useServerFn(acceptDeliveryOrder);
  const advanceOrder = useServerFn(advanceDeliveryOrder);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setSessionUser(data.user?.email ?? null));
    const { data } = supabase.auth.onAuthStateChange((_event, session) => setSessionUser(session?.user.email ?? null));
    return () => data.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const onPrompt = (event: Event) => { event.preventDefault(); setInstallPrompt(event as InstallPromptEvent); };
    const onInstalled = () => { setInstalled(true); setInstallPrompt(null); };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    setInstalled(window.matchMedia("(display-mode: standalone)").matches);
    return () => { window.removeEventListener("beforeinstallprompt", onPrompt); window.removeEventListener("appinstalled", onInstalled); };
  }, []);

  useEffect(() => {
    if (!sessionUser || panel !== "rider") return;
    loadDashboard().then(setDashboard).catch(() => setNotice(t.invalid));
  }, [sessionUser, panel, loadDashboard, t.invalid]);

  useEffect(() => {
    if (!trackingInput.code || !trackingInput.secret || panel !== "track") return;
    const refresh = () => trackOrder({ data: trackingInput }).then((result) => {
      setTracking((previous) => {
        if (previous && previous.order.status !== result.order.status) setNotice(language === "pt" ? `Atualização: ${t.statuses[result.order.status]}` : `Update: ${t.statuses[result.order.status]}`);
        return result;
      });
    }).catch(() => undefined);
    const timer = window.setInterval(refresh, 8000);
    return () => window.clearInterval(timer);
  }, [language, panel, t.statuses, trackOrder, trackingInput]);

  async function onOrderSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setNotice("");
    const form = new FormData(event.currentTarget);
    const parsed = orderSchema.safeParse(Object.fromEntries(form));
    if (!parsed.success) { setNotice(t.invalid); setBusy(false); return; }
    try {
      const result = await createOrder({ data: parsed.data });
      setCredentials({ code: result.code, secret: result.secret });
      setTrackingInput({ code: result.code, secret: result.secret });
      event.currentTarget.reset();
    } catch (error) { setNotice(error instanceof Error ? error.message : t.invalid); }
    finally { setBusy(false); }
  }

  async function onTrackSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setNotice("");
    try { setTracking(await trackOrder({ data: trackingInput })); }
    catch (error) { setTracking(null); setNotice(error instanceof Error ? error.message : t.invalid); }
    finally { setBusy(false); }
  }

  async function onAuth(event: FormEvent<HTMLFormElement>, mode: "in" | "up") {
    event.preventDefault(); setBusy(true); setNotice("");
    const form = new FormData(event.currentTarget);
    const email = String(form.get("email") ?? "").trim();
    const password = String(form.get("password") ?? "");
    if (!z.string().email().safeParse(email).success || password.length < 8) { setNotice(t.invalid); setBusy(false); return; }
    const result = mode === "up" ? await supabase.auth.signUp({ email, password }) : await supabase.auth.signInWithPassword({ email, password });
    setNotice(result.error ? result.error.message : mode === "up" && !result.data.session ? (language === "pt" ? "Confira seu e-mail para confirmar a conta." : "Check your email to confirm your account.") : "");
    setBusy(false);
  }

  async function onApplication(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setNotice("");
    const form = new FormData(event.currentTarget);
    try {
      await sendApplication({ data: { name: String(form.get("name") ?? ""), phone: String(form.get("phone") ?? ""), cityRegion: String(form.get("cityRegion") ?? ""), vehicle: String(form.get("vehicle") ?? ""), availability: String(form.get("availability") ?? "") } });
      setDashboard(await loadDashboard());
    } catch (error) { setNotice(error instanceof Error ? error.message : t.invalid); }
    finally { setBusy(false); }
  }

  async function refreshDashboard() { setDashboard(await loadDashboard()); }

  async function installApp() {
    if (installed) { setNotice(t.installed); return; }
    if (installPrompt) { await installPrompt.prompt(); const choice = await installPrompt.userChoice; if (choice.outcome === "accepted") setInstallPrompt(null); return; }
    setNotice(/iPhone|iPad|iPod/.test(navigator.userAgent) ? t.installIos : t.installUnavailable);
  }

  const statusOrder = ["sent", "accepted", "on_the_way", "delivered"] as const;
  const currentStatus = tracking?.order.status ?? "sent";
  const currentIndex = statusOrder.indexOf(currentStatus);

  return (
    <section id="entregas" className="border-b border-border bg-surface py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-end">
          <div><p className="eyebrow">{t.eyebrow}</p><h2 className="section-title">{t.titleA}<br /><span className="text-primary">{t.titleB}</span></h2><p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground">{t.intro}</p></div>
          <div className="grid gap-px border border-border bg-border sm:grid-cols-2">
            <div className="bg-background p-5"><p className="font-mono text-xs font-bold uppercase text-primary">{t.why}</p><p className="mt-3 text-sm leading-relaxed text-muted-foreground">{t.whyText}</p></div>
            <div className="bg-background p-5"><div className="flex gap-3"><MapPin className="mt-0.5 size-5 shrink-0 text-primary" /><div><strong className="block uppercase">{t.now}</strong><span className="text-sm text-muted-foreground">{t.nowText}</span></div></div><div className="mt-5 flex gap-3"><Route className="mt-0.5 size-5 shrink-0 text-warning" /><div><strong className="block uppercase">{t.soon}</strong><span className="text-sm text-muted-foreground">{t.soonText}</span></div></div></div>
          </div>
        </div>

        <div className="mt-10 grid gap-3 md:grid-cols-3">
          {[[Smartphone, t.client, t.clientText], [Bike, t.rider, t.riderText], [CircleDollarSign, t.fair, t.fairText]].map(([RawIcon, title, text]) => { const Icon = RawIcon as typeof Bike; return <article key={String(title)} className="border border-border bg-background p-5"><Icon className="size-7 text-primary" /><h3 className="mt-6 font-display text-2xl font-black uppercase">{String(title)}</h3><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{String(text)}</p></article>; })}
        </div>
        <div className="mt-3 flex items-start gap-3 border border-primary/40 bg-background p-5"><ShieldCheck className="mt-0.5 size-5 shrink-0 text-primary" /><p className="text-sm font-semibold leading-relaxed">{t.transparency}</p></div>

        <div className="mt-10 border border-border bg-background">
          <div className="flex flex-wrap border-b border-border">
            {([['order', PackageCheck, t.orderTab], ['track', Route, t.trackTab], ['rider', UserRoundCheck, t.riderTab]] as const).map(([key, Icon, label]) => <button key={key} type="button" onClick={() => { setPanel(key); setNotice(""); }} className={`flex min-h-12 flex-1 items-center justify-center gap-2 border-r border-border px-3 text-xs font-black uppercase transition-colors ${panel === key ? "bg-primary text-primary-foreground" : "hover:text-primary"}`}><Icon className="size-4" />{label}</button>)}
            <button type="button" onClick={installApp} className="flex min-h-12 flex-1 items-center justify-center gap-2 px-3 text-xs font-black uppercase text-primary hover:bg-primary hover:text-primary-foreground"><Download className="size-4" />{t.install}</button>
          </div>

          {notice && <div role="status" className="border-b border-warning/50 bg-warning/10 px-5 py-3 text-sm font-semibold text-warning">{notice}</div>}

          {panel === "order" && <div className="grid gap-8 p-5 sm:p-8 lg:grid-cols-[0.7fr_1.3fr]"><div><p className="eyebrow">{t.coverage}</p><h3 className="font-display text-4xl font-black uppercase">{t.orderTab}</h3><p className="mt-4 text-sm leading-relaxed text-muted-foreground">{t.riderPrices}</p></div>{credentials ? <div className="border border-primary p-5"><Check className="size-8 text-primary" /><h4 className="mt-4 font-display text-2xl font-black uppercase">{t.orderReady}</h4><dl className="mt-5 grid gap-3"><div><dt className="text-xs uppercase text-muted-foreground">{t.code}</dt><dd className="mt-1 font-mono text-xl font-bold text-primary">{credentials.code}</dd></div><div><dt className="text-xs uppercase text-muted-foreground">{t.secret}</dt><dd className="mt-1 break-all font-mono text-sm">{credentials.secret}</dd></div></dl><p className="mt-4 text-xs text-warning">{t.saveWarning}</p><button type="button" className="btn-primary mt-5" onClick={async () => { await navigator.clipboard.writeText(`${t.code}: ${credentials.code}\n${t.secret}: ${credentials.secret}`); setNotice(t.copied); }}><Copy className="size-4" />{t.copyData}</button></div> : <form onSubmit={onOrderSubmit} className="grid gap-4 sm:grid-cols-2"><Input name="customerName" label={t.name} className={inputClass} /><Input name="customerPhone" label={t.phone} type="tel" className={inputClass} /><Input name="city" label={t.city} defaultValue="Rolândia-PR" className={inputClass} /><Select name="paymentMethod" label={t.payment} className={inputClass} options={[["pix", "PIX"], ["mottucoin", "$MOTTUCOIN"]]} /><Input name="pickupAddress" label={t.pickup} className={inputClass} wide /><Input name="deliveryAddress" label={t.dropoff} className={inputClass} wide /><Input name="itemDescription" label={t.item} className={inputClass} wide /><button disabled={busy} className="btn-primary btn-large sm:col-span-2" type="submit">{busy ? t.sending : t.send}<Send className="size-4" /></button></form>}</div>}

          {panel === "track" && <div className="grid gap-8 p-5 sm:p-8 lg:grid-cols-[0.7fr_1.3fr]"><div><p className="eyebrow">{t.trackTab}</p><h3 className="font-display text-4xl font-black uppercase">{t.track}</h3><p className="mt-4 text-sm leading-relaxed text-muted-foreground">{t.trackHelp}</p><form onSubmit={onTrackSubmit} className="mt-6 grid gap-4"><Input label={t.code} value={trackingInput.code} onChange={(value) => setTrackingInput((old) => ({ ...old, code: value.toUpperCase() }))} className={inputClass} /><Input label={t.secret} value={trackingInput.secret} onChange={(value) => setTrackingInput((old) => ({ ...old, secret: value.toLowerCase() }))} className={inputClass} /><button className="btn-primary" disabled={busy}>{busy ? t.updating : t.track}<ArrowRight className="size-4" /></button></form></div><div>{tracking ? <><div className="grid grid-cols-4 gap-1">{statusOrder.map((status, index) => <div key={status} className="min-w-0"><div className={`h-2 ${index <= currentIndex ? "bg-primary" : "bg-border"}`} /><p className={`mt-2 text-center text-[10px] font-bold uppercase sm:text-xs ${index <= currentIndex ? "text-primary" : "text-muted-foreground"}`}>{t.statuses[status]}</p></div>)}</div><div className="mt-7 grid gap-px border border-border bg-border sm:grid-cols-2"><Info label={t.item} value={tracking.order.item_description} /><Info label={t.payment} value={tracking.order.payment_method === "pix" ? "PIX" : "$MOTTUCOIN"} /><Info label={t.price} value={tracking.order.proposed_amount ? `R$ ${Number(tracking.order.proposed_amount).toFixed(2)}` : t.waitingPrice} /><Info label={t.riderName} value={tracking.order.rider_name ?? "—"} /></div><div className="mt-5 flex items-start gap-3 text-xs text-muted-foreground"><Bell className="size-4 shrink-0 text-primary" />{t.notifications}</div></> : <div className="grid min-h-64 place-items-center border border-dashed border-border text-center text-muted-foreground"><div><Route className="mx-auto size-9 text-primary" /><p className="mt-3 text-sm">{t.trackHelp}</p></div></div>}</div></div>}

          {panel === "rider" && <div className="p-5 sm:p-8">{!sessionUser ? <RiderAuth language={language} t={t} busy={busy} onAuth={onAuth} setBusy={setBusy} setNotice={setNotice} /> : <div><div className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-5"><div><p className="eyebrow">{t.authTitle}</p><p className="text-sm text-muted-foreground">{sessionUser}</p></div><button className="btn-outline" type="button" onClick={() => supabase.auth.signOut()}>{t.signOut}</button></div>{!dashboard?.application ? <form onSubmit={onApplication} className="mx-auto mt-7 grid max-w-2xl gap-4 sm:grid-cols-2"><div className="sm:col-span-2"><h3 className="font-display text-3xl font-black uppercase">{t.applyTitle}</h3><p className="mt-2 text-sm text-muted-foreground">{t.applyHint}</p></div><Input name="name" label={t.name} className={inputClass} /><Input name="phone" label={t.phone} type="tel" className={inputClass} /><Input name="cityRegion" label={t.region} className={inputClass} /><Input name="vehicle" label={t.vehicle} className={inputClass} /><Input name="availability" label={t.availability} className={inputClass} wide /><button className="btn-primary btn-large sm:col-span-2" disabled={busy}>{t.apply}<Send className="size-4" /></button></form> : dashboard.application.approval_status !== "approved" ? <div className="mx-auto mt-8 max-w-xl border border-warning/50 p-6 text-center"><Clock3 className="mx-auto size-9 text-warning" /><h3 className="mt-4 font-display text-3xl font-black uppercase">{dashboard.application.approval_status === "pending" ? t.pending : t.rejected}</h3></div> : <div className="mt-7"><div className="flex items-center gap-2 text-primary"><UserRoundCheck className="size-5" /><strong className="uppercase">{t.approved}</strong></div><h3 className="mt-6 font-display text-3xl font-black uppercase">{t.available}</h3><div className="mt-4 grid gap-3">{dashboard.orders.length === 0 ? <p className="border border-dashed border-border p-8 text-center text-muted-foreground">{t.noOrders}</p> : dashboard.orders.map((order) => <RiderOrder key={order.id} order={order} t={t} onAccept={async (amount) => { await acceptOrder({ data: { orderId: order.id, proposedAmount: amount } }); await refreshDashboard(); }} onAdvance={async (nextStatus) => { await advanceOrder({ data: { orderId: order.id, nextStatus } }); await refreshDashboard(); }} />)}</div></div>}</div>}</div>}
        </div>
      </div>
    </section>
  );
}

function Input({ label, wide, className, onChange, ...props }: { label: string; wide?: boolean; className: string; name?: string; type?: string; defaultValue?: string; value?: string; onChange?: (value: string) => void }) {
  return <label className={wide ? "sm:col-span-2" : ""}><span className="mb-1.5 block text-xs font-bold uppercase text-muted-foreground">{label}</span><input required maxLength={props.name === "itemDescription" ? 500 : 300} {...props} onChange={onChange ? (event) => onChange(event.target.value) : undefined} className={className} /></label>;
}

function Select({ label, options, className, name }: { label: string; options: readonly (readonly [string, string])[]; className: string; name: string }) {
  return <label><span className="mb-1.5 block text-xs font-bold uppercase text-muted-foreground">{label}</span><select name={name} className={className}>{options.map(([value, text]) => <option key={value} value={value}>{text}</option>)}</select></label>;
}

function Info({ label, value }: { label: string; value: string }) { return <div className="bg-surface p-4"><p className="text-xs uppercase text-muted-foreground">{label}</p><p className="mt-1 font-semibold">{value}</p></div>; }

function RiderAuth({ language, t, busy, onAuth, setBusy, setNotice }: { language: Language; t: typeof copy.pt | typeof copy.en; busy: boolean; onAuth: (event: FormEvent<HTMLFormElement>, mode: "in" | "up") => Promise<void>; setBusy: (value: boolean) => void; setNotice: (value: string) => void }) {
  return <div className="mx-auto max-w-lg"><div className="text-center"><LogIn className="mx-auto size-9 text-primary" /><h3 className="mt-4 font-display text-4xl font-black uppercase">{t.authTitle}</h3><p className="mt-2 text-sm text-muted-foreground">{t.authHint}</p></div><form className="mt-7 grid gap-4" onSubmit={(event) => onAuth(event, "in")}><Input name="email" type="email" label={t.email} className={inputClass} /><Input name="password" type="password" label={t.password} className={inputClass} /><div className="grid gap-3 sm:grid-cols-2"><button disabled={busy} className="btn-primary" type="submit">{t.signIn}</button><button disabled={busy} className="btn-outline" type="button" onClick={(event) => { const form = event.currentTarget.closest("form"); if (form) void onAuth({ preventDefault: () => undefined, currentTarget: form } as FormEvent<HTMLFormElement>, "up"); }}>{t.signUp}</button></div></form><div className="my-5 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />OU / OR<span className="h-px flex-1 bg-border" /></div><button type="button" className="btn-outline w-full" onClick={async () => { setBusy(true); const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin }); if (result.error) setNotice(language === "pt" ? "Não foi possível entrar com Google." : "Could not sign in with Google."); setBusy(false); }}>{t.google}</button></div>;
}

function RiderOrder({ order, t, onAccept, onAdvance }: { order: RiderResult["orders"][number]; t: typeof copy.pt | typeof copy.en; onAccept: (amount: number) => Promise<void>; onAdvance: (status: "on_the_way" | "delivered") => Promise<void> }) {
  const [amount, setAmount] = useState("");
  const [busy, setBusy] = useState(false);
  return <article className="border border-border bg-surface p-5"><div className="flex flex-wrap items-start justify-between gap-3"><div><span className="status-chip">{t.statuses[order.status]}</span><h4 className="mt-3 font-display text-2xl font-black uppercase">{order.item_description}</h4><p className="mt-1 text-sm text-muted-foreground">{order.city}</p></div><code className="font-mono text-xs text-primary">{order.tracking_code}</code></div><div className="mt-5 grid gap-3 text-sm sm:grid-cols-2"><p><strong>{t.pickup}:</strong><br /><span className="text-muted-foreground">{order.pickup_address}</span></p><p><strong>{t.dropoff}:</strong><br /><span className="text-muted-foreground">{order.delivery_address}</span></p></div>{order.status === "sent" ? <div className="mt-5 flex flex-col gap-3 sm:flex-row"><input className={inputClass} type="number" min="0.01" step="0.01" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder={t.proposal} aria-label={t.proposal} /><button className="btn-primary shrink-0" disabled={busy || Number(amount) <= 0} onClick={async () => { setBusy(true); await onAccept(Number(amount)); setBusy(false); }}>{t.accept}</button></div> : <div className="mt-5 flex items-center justify-between gap-3 border-t border-border pt-4"><strong>{t.price}: R$ {Number(order.proposed_amount).toFixed(2)}</strong>{order.status === "accepted" && <button className="btn-primary" disabled={busy} onClick={async () => { setBusy(true); await onAdvance("on_the_way"); setBusy(false); }}>{t.onWay}</button>}{order.status === "on_the_way" && <button className="btn-primary" disabled={busy} onClick={async () => { setBusy(true); await onAdvance("delivered"); setBusy(false); }}>{t.delivered}</button>}</div>}</article>;
}