import { useQuery } from "@tanstack/react-query";
import { ArrowRight, ExternalLink, RefreshCw, ShieldCheck } from "lucide-react";

type Language = "pt" | "en";

type DexPair = {
  priceUsd?: string;
  priceNative?: string;
  priceChange?: { h24?: number };
  liquidity?: { usd?: number };
  marketCap?: number;
};

const CONTRACT = "BqV5L1apSdYjKEAa54qS9WCQdoSwpaNjcFYvBGoVpump";
const PUMP_URL = `https://pump.fun/coin/${CONTRACT}`;
const SOLSCAN_URL = `https://solscan.io/token/${CONTRACT}`;
const BIRDEYE_URL = `https://birdeye.so/token/${CONTRACT}?chain=solana`;
const JUPITER_URL = `https://jup.ag/swap/SOL-${CONTRACT}`;

const copy = {
  pt: {
    eyebrow: "Comprar / Swap",
    titleA: "Compre $MOTTU.",
    titleB: "Confira primeiro.",
    intro: "Acompanhe o preço e escolha onde comprar. O site não guarda sua carteira nem seus fundos.",
    price: "Preço atual",
    change: "Variação 24h",
    liquidity: "Liquidez",
    marketCap: "Valor de mercado",
    loading: "Buscando preço...",
    unavailable: "Preço indisponível agora",
    updated: "Dados públicos do DexScreener",
    refresh: "Atualizar preço",
    contract: "Contrato Solana",
    verify: "Sempre confira o contrato antes de trocar.",
    buyPump: "Comprar na Pump.fun",
    swapJupiter: "Swap na Jupiter",
    links: "Verificadores oficiais",
  },
  en: {
    eyebrow: "Buy / Swap",
    titleA: "Buy $MOTTU.",
    titleB: "Verify first.",
    intro: "Follow the price and choose where to buy. This website never holds your wallet or funds.",
    price: "Current price",
    change: "24h change",
    liquidity: "Liquidity",
    marketCap: "Market cap",
    loading: "Fetching price...",
    unavailable: "Price currently unavailable",
    updated: "Public DexScreener data",
    refresh: "Refresh price",
    contract: "Solana contract",
    verify: "Always verify the contract before swapping.",
    buyPump: "Buy on Pump.fun",
    swapJupiter: "Swap on Jupiter",
    links: "Official explorers",
  },
} as const;

async function getMarketPair() {
  const response = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${CONTRACT}`);
  if (!response.ok) throw new Error("Market data unavailable");
  const data = (await response.json()) as { pairs?: DexPair[] };
  return data.pairs?.[0] ?? null;
}

function money(value?: number) {
  if (typeof value !== "number") return "—";
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    notation: "compact",
    maximumFractionDigits: 2,
  }).format(value);
}

function tokenPrice(value?: string) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "—";
  return `$${number.toLocaleString("en-US", { minimumSignificantDigits: 2, maximumSignificantDigits: 6 })}`;
}

export function MarketSwap({ language }: { language: Language }) {
  const t = copy[language];
  const market = useQuery({
    queryKey: ["mottu-market", CONTRACT],
    queryFn: getMarketPair,
    refetchInterval: 60_000,
    staleTime: 30_000,
    retry: 1,
  });
  const change = market.data?.priceChange?.h24;

  return (
    <section id="comprar" className="border-b border-border bg-surface py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
          <div>
            <p className="eyebrow">{t.eyebrow}</p>
            <h2 className="section-title">{t.titleA}<br /><span className="text-primary">{t.titleB}</span></h2>
            <p className="mt-5 max-w-xl leading-relaxed text-muted-foreground">{t.intro}</p>
            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <a href={PUMP_URL} target="_blank" rel="noreferrer" className="btn-primary btn-large">{t.buyPump} <ArrowRight className="size-5" /></a>
              <a href={JUPITER_URL} target="_blank" rel="noreferrer" className="btn-outline btn-large">{t.swapJupiter} <ExternalLink className="size-4" /></a>
            </div>
          </div>

          <div className="border border-primary/50 bg-background">
            <div className="flex items-center gap-4 border-b border-border p-5 sm:p-6">
              <img src="/icon-192.png" alt="MottuCoin M" className="size-14 shrink-0" />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2"><strong className="font-display text-2xl uppercase">MottuCoin</strong><span className="status-chip">$MOTTU</span></div>
                <p className="mt-1 font-mono text-xs text-muted-foreground">Solana</p>
              </div>
              <button type="button" onClick={() => market.refetch()} className="icon-button shrink-0" aria-label={t.refresh} title={t.refresh}>
                <RefreshCw className={`size-4 ${market.isFetching ? "animate-spin" : ""}`} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-px bg-border">
              <div className="col-span-2 bg-background p-5 sm:p-6">
                <p className="text-xs font-bold uppercase text-muted-foreground">{t.price}</p>
                <p className="mt-2 font-mono text-3xl font-bold text-primary sm:text-4xl">
                  {market.isPending ? t.loading : market.isError || !market.data ? t.unavailable : tokenPrice(market.data.priceUsd)}
                </p>
                {market.data?.priceNative && <p className="mt-1 text-xs text-muted-foreground">{market.data.priceNative} SOL</p>}
              </div>
              <div className="bg-background p-4 sm:p-5"><p className="text-xs uppercase text-muted-foreground">{t.change}</p><p className={`mt-1 font-mono text-lg font-bold ${typeof change === "number" && change >= 0 ? "text-primary" : "text-destructive"}`}>{typeof change === "number" ? `${change > 0 ? "+" : ""}${change.toFixed(2)}%` : "—"}</p></div>
              <div className="bg-background p-4 sm:p-5"><p className="text-xs uppercase text-muted-foreground">{t.liquidity}</p><p className="mt-1 font-mono text-lg font-bold">{money(market.data?.liquidity?.usd)}</p></div>
              <div className="col-span-2 bg-background p-4 sm:p-5"><p className="text-xs uppercase text-muted-foreground">{t.marketCap}</p><p className="mt-1 font-mono text-lg font-bold">{money(market.data?.marketCap)}</p></div>
            </div>
            <p className="border-t border-border px-5 py-3 text-xs text-muted-foreground">{t.updated}</p>
          </div>
        </div>

        <div className="mt-8 border border-border bg-background p-5 sm:p-6">
          <div className="flex items-start gap-3"><ShieldCheck className="mt-0.5 size-5 shrink-0 text-primary" /><div className="min-w-0"><p className="text-xs font-bold uppercase text-primary">{t.contract}</p><code className="mt-2 block overflow-hidden text-ellipsis whitespace-nowrap font-mono text-sm">{CONTRACT}</code><p className="mt-2 text-xs text-muted-foreground">{t.verify}</p></div></div>
          <div className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {[["Solscan", SOLSCAN_URL], ["Pump.fun", PUMP_URL], ["Birdeye", BIRDEYE_URL]].map(([name, url]) => (
              <a key={name} href={url} target="_blank" rel="noreferrer" className="platform-link"><span><strong>{name}</strong><small>{t.links}</small></span><ExternalLink className="size-4 text-primary" /></a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}