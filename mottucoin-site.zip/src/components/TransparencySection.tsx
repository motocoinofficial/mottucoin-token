import { ChevronDown, ExternalLink, FileText, ShieldCheck } from "lucide-react";

const CONTRACT = "BqV5L1apSdYjKEAa54qS9WCQdoSwpaNjcFYvBGoVpump";
const explorers = [
  { name: "Solscan", url: `https://solscan.io/token/${CONTRACT}` },
  { name: "SolanaFM", url: `https://solanafm.com/token/${CONTRACT}` },
];
const copy = {
  pt: {
    eyebrow: "Prestação de contas", title: "Painel de Transparência — MottuCoin",
    updated: "Atualização informada pelo projeto: 10/10/2026 · 14:32 (UTC-3)",
    chainTitle: "Dados blockchain — conferência pública",
    chainSource: "Rede: Solana · Exploradores: Solscan / SolanaFM",
    disclaimer: "Os dados abaixo foram fornecidos pelo projeto. Esta página não realizou uma auditoria nem uma consulta completa à blockchain para confirmá-los. Um link para um explorador, sozinho, não comprova a informação.",
    headers: ["Item", "Informação fornecida", "Status"],
    chainRows: [
      ["Contrato renunciado", "Sem controle administrativo, segundo o projeto.", "Verificação independente pendente"],
      ["Liquidez permanente", "Sem possibilidade de retirada, segundo o projeto.", "Verificação independente pendente"],
      ["Supply total", "1.000.000.000 tokens", "Verificação independente pendente"],
      ["Queima de tokens", "O projeto informa não haver queima on-chain registrada até esta atualização.", "Registro comprobatório não fornecido"],
      ["Distribuição inicial", "100% alocada na piscina de liquidez, segundo o projeto.", "Verificação independente pendente"],
    ],
    projectTitle: "Informações fornecidas pelo projeto", projectSource: "Fonte: Equipe MottuCoin · Declarações institucionais",
    projectRows: [
      ["Alocação da equipe", "0% de tokens para equipe", "Verificação independente pendente"],
      ["Programa de queima", "1.000.000 de $MOTTU programados todo dia 1º do mês", "Aguardando registro on-chain"],
      ["Programa cashback", "Em fase inicial de operação", "Relatórios internos — ainda não auditado"],
      ["Princípios", "Sem bots · Crescimento orgânico", "Política do projeto"],
    ],
    note: "Registros on-chain podem ser conferidos nos exploradores públicos. Metas, políticas e planos são declarações do projeto e devem ser atualizados com evidências conforme forem implementados. Criptomoedas envolvem riscos; não há garantia de segurança ou valorização.",
    faqTitle: "Comunidade e indicações", faqs: [
      ["Como faço para participar da comunidade?", "Acesse o Telegram oficial: t.me/mottucoin_official. É onde compartilhamos novidades e conversamos com a comunidade. Para entrar no programa de indicações, aceite as regras na seção de indicações deste site."],
      ["Como funciona o programa de indicações?", "Ao aceitar as regras no site, você recebe automaticamente seu link único, sem cadastro manual. Quem entra pelo seu link fica vinculado à sua indicação, respeitando os critérios de elegibilidade. Entrar no Telegram, sozinho, não gera esse link."],
      ["Tem recompensa para quem indica?", "5% sobre compras diretas confirmadas e 2% sobre compras do segundo nível. A liberação ocorre após 30 dias da compra confirmada; se o comprador vender antes de 15 dias, a comissão é perdida. O limite total é US$ 50 por mês por indicador. Mesmo IP ou dispositivo não contam como nova indicação. Carteira Solana e compra precisam ser verificadas; não são criados tokens novos."],
      ["Onde acompanho minhas indicações e ganhos?", "Na seção de indicações deste site, no aparelho em que você entrou: confira as indicações diretas, o segundo nível e as comissões pendentes ou disponíveis. A confirmação da carteira e das compras também acontece ali. Não há consulta por botão ou comando do Telegram integrada a este site."],
      ["Quais são os canais oficiais?", "Sites: mottucoin.com.br e mottucoin.com. Telegram: t.me/mottucoin_official. X/Twitter: x.com/mottucoin. Confira sempre os endereços e o contrato antes de conectar uma carteira ou comprar."],
    ], telegram: "Telegram oficial", referrals: "Minhas indicações",
  },
  en: {
    eyebrow: "Accountability", title: "Transparency Panel — MottuCoin",
    updated: "Project-reported update: 10 October 2026 · 14:32 (UTC−3)",
    chainTitle: "Blockchain data — public verification", chainSource: "Network: Solana · Explorers: Solscan / SolanaFM",
    disclaimer: "The information below was supplied by the project. This page has not performed an audit or a complete blockchain review to confirm it. An explorer link alone does not prove a claim.",
    headers: ["Item", "Supplied information", "Status"],
    chainRows: [
      ["Renounced contract", "No administrative control, according to the project.", "Independent verification pending"],
      ["Permanent liquidity", "Cannot be withdrawn, according to the project.", "Independent verification pending"],
      ["Total supply", "1,000,000,000 tokens", "Independent verification pending"],
      ["Token burns", "The project reports no recorded on-chain burns as of this update.", "Supporting record not supplied"],
      ["Initial distribution", "100% allocated to the liquidity pool, according to the project.", "Independent verification pending"],
    ],
    projectTitle: "Information supplied by the project", projectSource: "Source: MottuCoin team · Institutional statements",
    projectRows: [
      ["Team allocation", "0% of tokens allocated to the team", "Independent verification pending"],
      ["Burn programme", "1,000,000 $MOTTU scheduled on the 1st of each month", "Awaiting on-chain record"],
      ["Cashback programme", "Early operating phase", "Internal reports — not yet audited"],
      ["Principles", "No bots · Organic growth", "Project policy"],
    ],
    note: "On-chain records can be checked using public explorers. Goals, policies and plans are project statements and should be updated with evidence as they are implemented. Cryptocurrencies involve risks; safety and price appreciation are not guaranteed.",
    faqTitle: "Community and referrals", faqs: [
      ["How do I join the community?", "Visit the official Telegram group: t.me/mottucoin_official. We share updates and talk to the community there. To join the referral programme, accept the rules in this site's referrals section."],
      ["How does the referral programme work?", "After accepting the rules on this site, you automatically receive a unique link without manual registration. People who enter through it are attributed to you, subject to eligibility checks. Joining Telegram alone does not generate a referral link."],
      ["Are there rewards for referrals?", "5% on confirmed direct purchases and 2% on second-level purchases. Commission is released after 30 days from the confirmed purchase; if the buyer sells before 15 days, commission is forfeited. The total cap is US$50 per month per referrer. The same IP or device does not count as a new referral. Solana wallet ownership and purchases must be verified; no new tokens are minted."],
      ["Where can I track referrals and rewards?", "In this site's referrals section, on the device you joined with: check direct referrals, the second level and pending or available commissions. Wallet and purchase confirmations also take place there. No Telegram dashboard button or command is integrated with this site."],
      ["What are the official channels?", "Websites: mottucoin.com.br and mottucoin.com. Telegram: t.me/mottucoin_official. X/Twitter: x.com/mottucoin. Always check the addresses and contract before connecting a wallet or buying."],
    ], telegram: "Official Telegram", referrals: "My referrals",
  },
} as const;

export function TransparencySection({ language }: { language: "pt" | "en" }) {
  const t = copy[language];
  const groups = [
    { title: t.chainTitle, source: t.chainSource, rows: t.chainRows, Icon: ShieldCheck, showExplorers: true },
    { title: t.projectTitle, source: t.projectSource, rows: t.projectRows, Icon: FileText, showExplorers: false },
  ];
  return (
    <section id="transparencia" className="scroll-mt-20 border-b border-border bg-surface py-16 sm:py-24" aria-labelledby="transparency-title">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <p className="eyebrow">{t.eyebrow}</p>
        <h2 id="transparency-title" className="section-title">{t.title}</h2>
        <p className="mt-4 font-mono text-xs text-muted-foreground"><time dateTime="2026-10-10T14:32:00-03:00">{t.updated}</time></p>
        <p className="mt-6 max-w-4xl border-l-2 border-warning pl-4 text-sm leading-relaxed text-muted-foreground">{t.disclaimer}</p>
        {groups.map(({ title, source, rows, Icon, showExplorers }) => (
          <div key={title} className="mt-10">
            <h3 className="flex items-start gap-3 font-display text-2xl font-bold uppercase"><Icon className="mt-1 size-6 shrink-0 text-primary" />{title}</h3>
            <p className="mt-2 text-xs text-muted-foreground">{source}</p>
            <table className="mt-5 w-full table-fixed border-y border-border text-left text-sm">
              <thead className="bg-background"><tr>{t.headers.map((header) => <th key={header} scope="col" className="break-words p-2 font-semibold sm:p-4">{header}</th>)}</tr></thead>
              <tbody className="divide-y divide-border">{rows.map(([item, info, status]) => <tr key={item}><th scope="row" className="break-words p-2 align-top font-semibold sm:p-4">{item}{showExplorers && <div className="mt-3 flex flex-col gap-2 text-xs font-semibold text-primary sm:flex-row sm:flex-wrap sm:gap-3">{explorers.map(({ name, url }) => <a key={name} href={url} target="_blank" rel="noopener noreferrer" aria-label={`${item} — ${name}`} className="inline-flex w-fit items-center gap-1 underline underline-offset-4 hover:text-foreground">{name}<ExternalLink aria-hidden="true" className="size-3 shrink-0" /></a>)}</div>}</th><td className="break-words p-2 align-top leading-relaxed text-muted-foreground sm:p-4">{info}</td><td className="break-words p-2 align-top text-xs leading-relaxed text-warning sm:p-4">{status}</td></tr>)}</tbody>
            </table>
          </div>
        ))}
        <div className="mt-6 flex flex-wrap gap-5 text-sm font-bold text-primary">
          {explorers.map(({ name, url }) => <a key={name} href={url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2">{name} <ExternalLink className="size-4" /></a>)}
        </div>
        <code className="mt-4 block break-all font-mono text-xs text-muted-foreground">{CONTRACT}</code>
        <p className="mt-5 max-w-4xl text-sm leading-relaxed text-muted-foreground">{t.note}</p>
        <div className="mt-14 border-t border-border pt-10">
          <h3 className="font-display text-3xl font-black uppercase">{t.faqTitle}</h3>
          <div className="mt-6 divide-y divide-border border-y border-border">{t.faqs.map(([question, answer]) => <details key={question} className="group py-5"><summary className="flex cursor-pointer list-none items-center justify-between gap-5 font-display text-lg font-bold uppercase"><span>{question}</span><ChevronDown className="size-5 shrink-0 text-primary transition-transform group-open:rotate-180" /></summary><p className="max-w-4xl pt-4 text-sm leading-relaxed text-muted-foreground">{answer}</p></details>)}</div>
          <div className="mt-6 flex flex-wrap gap-5 text-sm font-bold text-primary"><a href="https://t.me/mottucoin_official" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2">{t.telegram} <ExternalLink className="size-4" /></a><a href="#comunidade" className="inline-flex items-center gap-2">{t.referrals} <ChevronDown className="size-4" /></a></div>
        </div>
      </div>
    </section>
  );
}