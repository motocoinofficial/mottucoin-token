import { useEffect, useState, type FormEvent } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Check, Copy, Link2, Network, ShieldCheck, Users, WalletCards } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  getCommunityDashboard,
  joinCommunity,
  registerReferralVisit,
  createWalletChallenge,
  confirmCommunityWallet,
  confirmCommunityPurchase,
} from "@/lib/community.functions";

type Language = "pt" | "en";
type Dashboard = Awaited<ReturnType<typeof getCommunityDashboard>>;

const DEVICE_KEY = "mottucoin-community-device";
const SECRET_KEY = "mottucoin-community-access";
const REFERRER_KEY = "mottucoin-community-referrer";

const copy = {
  pt: {
    eyebrow: "Comunidade por indicação", titleA: "Seu link.", titleB: "Sua rede.",
    intro: "Entre aceitando as regras e receba automaticamente um link único para convidar a comunidade.",
    referred: "Você chegou pelo link", noForm: "Sem cadastro manual", noFormText: "Aceite as regras e o acesso é liberado neste aparelho.",
    rulesTitle: "Regras transparentes", accept: "Li e aceito todas as regras da comunidade.", enter: "Aceitar e entrar", entering: "Liberando acesso...",
    rules: ["5% sobre compras diretas confirmadas", "2% sobre compras do segundo nível", "Liberação após 30 dias", "Venda antes de 15 dias perde a comissão", "Limite total de US$ 50 por mês", "Mesmo IP ou dispositivo não conta", "Pagamento em $MOTTU já existente — sem criar tokens"],
    yourLink: "Seu link único", copyLink: "Copiar link", copied: "Link copiado", direct: "Indicações diretas", network: "Segundo nível", month: "Comissão no mês", cap: "de US$ 50", pending: "$MOTTU pendente", available: "$MOTTU disponível", wallet: "Carteira Solana para receber", save: "Confirmar com Phantom", saved: "Carteira confirmada", walletHelp: "Assinatura sem cobrança. Compras em SOL na Pump.fun após confirmar a carteira são elegíveis.", invalidWallet: "Informe uma carteira Solana válida.", restored: "Seu acesso foi recuperado neste aparelho.", blocked: "Este dispositivo ou conexão já participa da comunidade.", unavailable: "Não foi possível carregar a comunidade agora.", share: "Compartilhe este link. O indicador é registrado automaticamente quando alguém acessa.",
  },
  en: {
    eyebrow: "Referral community", titleA: "Your link.", titleB: "Your network.",
    intro: "Accept the rules to join and automatically receive a unique link to invite the community.",
    referred: "You arrived through link", noForm: "No manual registration", noFormText: "Accept the rules and access is unlocked on this device.",
    rulesTitle: "Transparent rules", accept: "I have read and accept all community rules.", enter: "Accept and join", entering: "Unlocking access...",
    rules: ["5% on confirmed direct purchases", "2% on second-level purchases", "Released after 30 days", "Selling before 15 days forfeits commission", "US$50 total monthly cap", "The same IP or device does not count", "Paid in existing $MOTTU — no new tokens"],
    yourLink: "Your unique link", copyLink: "Copy link", copied: "Link copied", direct: "Direct referrals", network: "Second level", month: "Commission this month", cap: "of US$50", pending: "Pending $MOTTU", available: "Available $MOTTU", wallet: "Solana wallet for payments", save: "Confirm with Phantom", saved: "Wallet confirmed", walletHelp: "No-charge message signature. SOL purchases on Pump.fun after wallet confirmation are eligible.", invalidWallet: "Enter a valid Solana wallet.", restored: "Your access was restored on this device.", blocked: "This device or connection already belongs to the community.", unavailable: "The community could not be loaded right now.", share: "Share this link. The referrer is recorded automatically when someone opens it.",
  },
} as const;

function getDeviceId() {
  const saved = window.localStorage.getItem(DEVICE_KEY);
  if (saved) return saved;
  const created = `${crypto.randomUUID()}-${crypto.randomUUID()}`;
  window.localStorage.setItem(DEVICE_KEY, created);
  return created;
}

export function CommunityReferral({ language }: { language: Language }) {
  const t = copy[language];
  const registerVisit = useServerFn(registerReferralVisit);
  const join = useServerFn(joinCommunity);
  const loadDashboard = useServerFn(getCommunityDashboard);
  const createChallenge = useServerFn(createWalletChallenge);
  const confirmWallet = useServerFn(confirmCommunityWallet);
  const confirmPurchase = useServerFn(confirmCommunityPurchase);
  const [accepted, setAccepted] = useState(false);
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [referrer, setReferrer] = useState<string | null>(null);
  const [secret, setSecret] = useState<string | null>(null);
  const [walletValue, setWalletValue] = useState("");
  const [purchaseSignature, setPurchaseSignature] = useState("");
  const [origin, setOrigin] = useState("");

  useEffect(() => {
    setOrigin(window.location.origin);
    const params = new URLSearchParams(window.location.search);
    const urlRef = params.get("ref")?.trim().toUpperCase();
    const code = urlRef && /^[A-F0-9]{10}$/.test(urlRef) ? urlRef : window.localStorage.getItem(REFERRER_KEY);
    const savedSecret = window.localStorage.getItem(SECRET_KEY);
    const deviceId = getDeviceId();
    if (code) {
      setReferrer(code);
      window.localStorage.setItem(REFERRER_KEY, code);
      registerVisit({ data: { code, deviceId } }).catch(() => undefined);
    }
    if (savedSecret) {
      setSecret(savedSecret);
      loadDashboard({ data: { secret: savedSecret } }).then((result) => { setDashboard(result); setWalletValue(result.wallet ?? ""); }).catch(() => window.localStorage.removeItem(SECRET_KEY));
    }
  }, [loadDashboard, registerVisit]);

  const referralUrl = dashboard ? `${origin}/?ref=${dashboard.code}#comunidade` : "";

  async function onJoin() {
    if (!accepted) return;
    setBusy(true); setNotice("");
    try {
      const result = await join({ data: { deviceId: getDeviceId(), referralCode: referrer ?? undefined, acceptedRules: true } });
      window.localStorage.setItem(SECRET_KEY, result.secret);
      setSecret(result.secret);
      const next = await loadDashboard({ data: { secret: result.secret } });
      setDashboard(next); setWalletValue(next.wallet ?? "");
    } catch (error) { setNotice(error instanceof Error ? error.message : t.unavailable); }
    finally { setBusy(false); }
  }

  async function onWallet(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!secret) return;
    setBusy(true); setNotice("");
    try {
      const provider = (window as unknown as { phantom?: { solana?: { connect: () => Promise<{ publicKey: { toString: () => string } }>; signMessage: (message: Uint8Array, encoding: string) => Promise<{ signature: Uint8Array }> } } }).phantom?.solana;
      if (!provider) throw new Error(language === "pt" ? "Abra o site no navegador da carteira Phantom para confirmar." : "Open this site in Phantom's browser to confirm.");
      const connection = await provider.connect();
      const address = connection.publicKey.toString();
      const challenge = await createChallenge({ data: { secret, wallet: address } });
      const signed = await provider.signMessage(new TextEncoder().encode(challenge.message), "utf8");
      await confirmWallet({ data: { secret, challengeId: challenge.id, signature: Array.from(signed.signature) } });
      setDashboard(await loadDashboard({ data: { secret } })); setWalletValue(address); setNotice(t.saved);
    } catch (error) { setNotice(error instanceof Error ? error.message : t.unavailable); }
    finally { setBusy(false); }
  }

  async function onPurchase(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!secret) return;
    setBusy(true); setNotice("");
    try {
      const result = await confirmPurchase({ data: { secret, signature: purchaseSignature } });
      setNotice(language === "pt" ? (result.recorded ? "Compra confirmada e comissões registradas." : "Compra verificada: sem novas comissões elegíveis.") : (result.recorded ? "Purchase confirmed and commissions recorded." : "Purchase verified: no new eligible commissions."));
      setDashboard(await loadDashboard({ data: { secret } }));
    } catch (error) { setNotice(error instanceof Error ? error.message : t.unavailable); }
    finally { setBusy(false); }
  }

  return (
    <section id="comunidade" className="border-b border-border bg-surface py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-[0.82fr_1.18fr] lg:items-start">
          <div><p className="eyebrow">{t.eyebrow}</p><h2 className="section-title">{t.titleA}<br /><span className="text-primary">{t.titleB}</span></h2><p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground">{t.intro}</p>
            <div className="mt-7 flex items-start gap-3 border-l-4 border-primary bg-background p-4"><ShieldCheck className="mt-0.5 size-5 shrink-0 text-primary" /><div><strong className="text-sm uppercase">{t.noForm}</strong><p className="mt-1 text-sm text-muted-foreground">{t.noFormText}</p></div></div>
          </div>
          {!dashboard ? <div className="border border-primary/40 bg-background p-5 sm:p-8">
            {referrer && <div className="mb-6 flex items-center gap-2 border border-primary/30 bg-primary/10 px-3 py-2 font-mono text-xs text-primary"><Link2 className="size-4" />{t.referred}: <strong>{referrer}</strong></div>}
            <h3 className="font-display text-3xl font-black uppercase">{t.rulesTitle}</h3>
            <ul className="mt-6 grid gap-3 sm:grid-cols-2">{t.rules.map((rule) => <li key={rule} className="flex items-start gap-2 text-sm leading-relaxed"><Check className="mt-0.5 size-4 shrink-0 text-primary" />{rule}</li>)}</ul>
            <label className="mt-7 flex cursor-pointer items-start gap-3 border-t border-border pt-5 text-sm font-semibold"><Checkbox checked={accepted} onCheckedChange={(value) => setAccepted(value === true)} aria-label={t.accept} className="mt-0.5 size-5" /><span>{t.accept}</span></label>
            {notice && <p role="status" className="mt-4 text-sm font-semibold text-warning">{notice}</p>}
            <Button type="button" onClick={onJoin} disabled={!accepted || busy} className="mt-5 min-h-12 w-full rounded-none font-black uppercase">{busy ? t.entering : t.enter}</Button>
          </div> : <div className="border border-primary/40 bg-background p-5 sm:p-8">
            <div className="flex items-center justify-between gap-4"><div><p className="eyebrow">{t.yourLink}</p><code className="font-mono text-sm font-bold text-primary">{dashboard.code}</code></div><Users className="size-8 text-primary" /></div>
            <div className="mt-5 flex min-w-0 border border-primary"><input aria-label={t.yourLink} readOnly value={referralUrl} className="min-w-0 flex-1 bg-surface px-3 font-mono text-xs outline-none" /><Button type="button" className="min-h-11 shrink-0 rounded-none font-bold uppercase" onClick={async () => { await navigator.clipboard.writeText(referralUrl); setNotice(t.copied); }}>{notice === t.copied ? <Check /> : <Copy />}{t.copyLink}</Button></div><p className="mt-3 text-xs text-muted-foreground">{t.share}</p>
            <div className="mt-7 grid gap-px border border-border bg-border sm:grid-cols-2"><Metric icon={Users} label={t.direct} value={String(dashboard.directCount)} /><Metric icon={Network} label={t.network} value={String(dashboard.networkCount)} /><Metric icon={WalletCards} label={t.month} value={`US$ ${dashboard.monthUsd.toFixed(2)}`} detail={t.cap} /><Metric icon={ShieldCheck} label={t.pending} value={dashboard.pendingMottu.toLocaleString()} /><Metric icon={WalletCards} label={t.available} value={dashboard.availableMottu.toLocaleString()} /><Metric icon={Check} label={language === "pt" ? "Próxima liberação" : "Next release"} value={dashboard.nextRelease ? new Date(dashboard.nextRelease).toLocaleDateString(language === "pt" ? "pt-BR" : "en-US") : "—"} /></div>
            <form onSubmit={onWallet} className="mt-7"><label className="text-xs font-bold uppercase text-muted-foreground">{t.wallet}<input readOnly value={walletValue} className="mt-2 min-h-12 w-full border border-border bg-surface px-3 font-mono text-sm outline-none focus:border-primary" /></label><p className="mt-2 text-xs text-muted-foreground">{t.walletHelp}</p><Button disabled={busy} className="mt-4 min-h-11 rounded-none font-black uppercase">{t.save}</Button></form>
            {dashboard.walletVerified && <><p className="mt-3 flex items-center gap-2 text-sm text-primary"><ShieldCheck className="size-4" />{language === "pt" ? "Carteira confirmada" : "Wallet confirmed"}</p><form onSubmit={onPurchase} className="mt-6 border-t border-border pt-5"><label className="text-xs font-bold uppercase text-muted-foreground">{language === "pt" ? "Transação da compra (assinatura Solana)" : "Purchase transaction (Solana signature)"}<input required value={purchaseSignature} onChange={(event) => setPurchaseSignature(event.target.value)} className="mt-2 min-h-12 w-full border border-border bg-surface px-3 font-mono text-xs outline-none focus:border-primary" /></label><Button disabled={busy} className="mt-3 rounded-none font-bold uppercase">{language === "pt" ? "Confirmar compra" : "Confirm purchase"}</Button></form></>}
            {dashboard.commissions.length > 0 && <div className="mt-6 border-t border-border pt-5"><h3 className="font-bold uppercase">{language === "pt" ? "Histórico de comissões" : "Commission history"}</h3>{dashboard.commissions.map((row) => <div key={row.id} className="mt-3 flex flex-wrap justify-between gap-2 border-b border-border pb-3 text-sm"><span>US$ {row.usd.toFixed(2)} · {row.level === 1 ? t.direct : t.network}</span><span className="text-primary">{({ pending: language === "pt" ? "Pendente" : "Pending", available: language === "pt" ? "Disponível" : "Available", forfeited: language === "pt" ? "Perdida por venda antecipada" : "Forfeited: early sale", paid: language === "pt" ? "Paga" : "Paid" } as Record<string, string>)[row.status]}</span><a href={`https://solscan.io/tx/${row.signature}`} target="_blank" rel="noreferrer" className="text-primary underline">Solscan</a></div>)}</div>}
            {notice && <p role="status" className="mt-4 text-sm font-semibold text-primary">{notice}</p>}
          </div>}
        </div>
      </div>
    </section>
  );
}

function Metric({ icon: Icon, label, value, detail }: { icon: typeof Users; label: string; value: string; detail?: string }) {
  return <div className="bg-surface p-4"><Icon className="size-5 text-primary" /><p className="mt-4 text-xs uppercase text-muted-foreground">{label}</p><p className="mt-1 font-display text-2xl font-black uppercase">{value}</p>{detail && <p className="text-xs text-muted-foreground">{detail}</p>}</div>;
}