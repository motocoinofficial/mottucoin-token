import { describe, expect, it } from "vitest";
import { inspectTrade, MOTTU_CONTRACT, PUMP_PROGRAMS, type ChainTransaction } from "@/lib/community-chain";

function transaction(delta: number, instruction = "Buy"): ChainTransaction {
  return { blockTime: 1791339000, meta: { err: null, logMessages: [`Program ${PUMP_PROGRAMS[0]} invoke [1]`, `Program log: Instruction: ${instruction}`], preTokenBalances: [{ mint: MOTTU_CONTRACT, owner: "wallet", uiTokenAmount: { amount: "100", decimals: 0 } }], postTokenBalances: [{ mint: MOTTU_CONTRACT, owner: "wallet", uiTokenAmount: { amount: String(100 + delta), decimals: 0 } }] }, transaction: { message: { accountKeys: [{ pubkey: "wallet", signer: true }], instructions: [] } } };
}
describe("Confirmed MOTTU activity", () => {
  it("accepts a signed market purchase", () => expect(inspectTrade(transaction(10), "wallet")?.kind).toBe("buy"));
  it("detects a signed sale", () => expect(inspectTrade(transaction(-10, "Sell"), "wallet")?.kind).toBe("sell"));
  it("rejects gifts and other wallets", () => {
    expect(inspectTrade(transaction(10, "Transfer"), "wallet")).toBeNull();
    expect(inspectTrade(transaction(10), "other")).toBeNull();
  });
  it("rejects failed or unrelated transactions", () => {
    const tx = transaction(10);
    if (tx.meta) tx.meta.err = { failure: true };
    expect(inspectTrade(tx, "wallet")).toBeNull();
    const unrelated = transaction(10);
    if (unrelated.meta) unrelated.meta.logMessages = ["Program log: Instruction: Buy"];
    expect(inspectTrade(unrelated, "wallet")).toBeNull();
  });
});