import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowRight,
  Bike,
  Check,
  CheckCircle2,
  ChevronDown,
  Copy,
  ExternalLink,
  Flame,
  LockKeyhole,
  Menu,
  ShieldCheck,
  ShoppingBag,
  TrendingUp,
  Users,
  WalletCards,
  X,
} from "lucide-react";

import unityAsset from "@/assets/mottu-rider-unity.jpg.asset.json";
import futureAsset from "@/assets/mottu-rider-future.jpg.asset.json";
import nightAsset from "@/assets/mottu-rider-night.jpg.asset.json";
import crewAsset from "@/assets/mottu-crew.jpg.asset.json";
import phoneAsset from "@/assets/mottu-phone.jpg.asset.json";
import rainAsset from "@/assets/mottu-rain.jpg.asset.json";
import { DeliverySection } from "@/components/DeliverySection";
import { MarketSwap } from "@/components/MarketSwap";
import { CommunityReferral } from "@/components/CommunityReferral";
import { TransparencySection } from "@/components/TransparencySection";

const CONTRACT = "BqV5L1apSdYjKEAa54qS9WCQdoSwpaNjcFYvBGoVpump";
const PUMP_URL = `https://pump.fun/coin/${CONTRACT}`;
const SOLSCAN_URL = `https://solscan.io/token/${CONTRACT}`;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MottuCoin | Feito por nós, para nós" },
      {
        name: "description",
        content:
          "MottuCoin ($MOTTU) na Solana: feito por um entregador para a comunidade, com compra via PIX, entregas justas e indicações.",
      },
      { property: "og:title", content: "MottuCoin | Feito por nós, para nós" },
      {
        property: "og:description",
        content: "Um projeto honesto, construído por um motoboy para crescer com a comunidade.",
      },
      { property: "og:image", content: nightAsset.url },
      { name: "twitter:image", content: nightAsset.url },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Language = "pt" | "en";

const content = {
  pt: {
    nav: [["Entregas", "#entregas"], ["Segurança", "#seguranca"], ["Tokenomics", "#tokenomics"], ["Como comprar", "#comprar"], ["Roadmap", "#roadmap"], ["FAQ", "#faq"]],
    buy: "Comprar $MOTTU", buyPump: "Comprar na Pump.fun", buyPix: "Comprar via PIX", viewContract: "Ver contrato",
    menuOpen: "Abrir menu", menuClose: "Fechar menu", mainNav: "Navegação principal", mobileNav: "Navegação móvel",
    heroPlace: "Nascida em Rolândia — PR", heroKicker: "A moeda de quem faz a cidade rodar.",
    heroTitleA: "MottuCoin.", heroTitleB: "Feito por nós, para nós.",
    heroText: "Criado por um entregador real, com mais de 15 anos nas estradas. Não nasceu em um escritório: nasceu de quem trabalha para fazer a cidade rodar. Cada passo fortalece a nossa gente.",
    trust: ["Contrato renunciado", "Liquidez protegida", "Sem taxas abusivas", "Compra via PIX"],
    contractEyebrow: "Contrato do token", contractTitle: "Confira. Copie. Verifique.", copy: "Copiar", copied: "Copiado", copyAria: "Copiar endereço do contrato",
    platforms: [["Pump.fun", "Página oficial"], ["Solscan", "Transparência total"]],
    securityEyebrow: "Por que confiar no $MOTTU?", securityTitleA: "Da rua.", securityTitleB: "À vista de todos.",
    securityText: "Criado na Pump.fun por quem conhece a rotina das entregas. Nosso compromisso é crescer organicamente, sem bots de volume ou negociações artificiais. Confira as informações públicas antes de comprar.", securityQuote: "“Não confie em palavras — confira no Solscan.”", openSolscan: "Abrir Solscan",
    securityItems: [
      ["Liquidez na curva de bonding", "Criado na Pump.fun. Confira a situação da curva e da liquidez nas plataformas oficiais: isso não elimina os riscos de uma criptomoeda."],
      ["Contrato oficial", "Confira as autoridades de emissão e congelamento no Solscan. O endereço oficial permite verificar o token, sem depender apenas de promessas."],
      ["Equipe: 0%", "Sem reserva de tokens para a equipe, conforme a distribuição declarada pelo projeto. Confira a distribuição pública no Solscan."],
    ],
    graduation: "Depois da graduação", graduationText: "A migração e o bloqueio da liquidez dependem da graduação e das regras da Pump.fun. Verifique o estado atual na plataforma; não existe risco zero.",
    tokenomics: "Tokenomics", tokenTitleA: "Simples.", tokenTitleB: "Sem pegadinha.", tokenData: [["Nome", "MottuCoin"], ["Símbolo", "$MOTTU"], ["Blockchain", "Solana"], ["Equipe", "0%"]],
    holderTitle: "O que você encontra sendo holder", holderBenefits: [
      ["Cashback & compras", "Shopee, Mercado Livre e Amazon: use os links oficiais. Parte das comissões de afiliados fortalece o projeto; condições de cashback dependem de cada programa."],
      ["Entregas justas", "90% fica com o entregador e 10% fortalece o projeto e a queima de tokens."],
      ["Indique e ganhe", "5% direto + 2% do segundo nível, após compra confirmada e 30 dias. Venda antes de 15 dias perde a comissão; teto de US$ 50 por mês e confirmação pela carteira Solana."],
      ["Queima mensal", "1 milhão de $MOTTU todo dia 1º, com comprovação pública. Reduzir a oferta não garante valorização."],
    ], familyLabel: "Números da nossa família", familyStats: [["25 milhões+", "Circulação informada pelo projeto"], ["1 milhão / mês", "Queima programada todo dia 1º"], ["15+ anos", "Experiência do criador nas estradas"]], statsNote: "Circulação declarada pelo projeto, não uma contagem ao vivo verificada. Confira oferta, distribuição e transações no Solscan.",
    monthlyBurn: "Queima mensal programada", burnAmount: "1.000.000", burnRule: "tokens todo dia 1º", burnText: "Meta informada pelo projeto. Até a atualização de 10/10/2026, o projeto informa não haver queima on-chain registrada. Aguardando transação comprobatória.", totalSupply: "Oferta total inicial", totalSupplyValue: "1 bilhão", transactionFee: "Taxa de transação", feeValue: "2% redistribuído",
    howTo: "Como comprar", stepsTitle: "PIX ou carteira Solana.", pixTitle: "Opção 1 — PIX pelo bot oficial", pixSteps: ["Abra o bot oficial e confira as instruções e o valor antes de pagar.", "Informe sua carteira Solana e faça o PIX indicado pelo bot.", "Após a confirmação do pagamento, confira o recebimento de $MOTTU na sua carteira."], walletTitle: "Opção 2 — Carteira Solana", purchaseCaution: "As compras e trocas acontecem nas plataformas externas oficiais. Nunca compartilhe sua frase secreta; confira o contrato e as condições antes de confirmar.", steps: [
      ["01", "Instale uma carteira", "Crie ou abra sua carteira Solana na Phantom ou Solflare. Guarde sua frase secreta e nunca compartilhe."],
      ["02", "Coloque saldo", "Compre SOL e transfira para sua carteira. Confira o endereço e reserve saldo para as taxas da rede."],
      ["03", "Compre $MOTTU", "Use os botões oficiais de compra ou swap deste site. Conecte sua carteira na plataforma escolhida e confira o contrato antes de trocar SOL por $MOTTU."],
    ],
    cashback: "Cashback & parcerias", cashbackTitle: "Compre o que usa. Fortaleça o projeto.", cashbackText: "Parte da comissão retorna para fortalecer o MottuCoin, sem custo extra para você.",
    stores: [["Shopee", "Tudo o que precisar"], ["Mercado Livre", "Produtos variados"], ["Amazon", "Equipamentos e capacetes"]], linkSoon: "Link em breve",
    roadmapLabel: "Roadmap", roadmapTitle: "Da rua para o futuro.", roadmap: [
      ["Lançamento na Pump.fun", "Concluído", true], ["Site oficial + redes sociais", "Concluído", true], ["Bot de compra via PIX", "Concluído", true], ["Cashback afiliado", "Ativo", true],
      ["Liquidez permanente", "Em andamento", false], ["Aplicativo MottuCoin", "Em desenvolvimento", false], ["Parcerias com marcas", "Em negociação", false], ["Listagem em outras plataformas", "Quando atingir volume", false],
    ],
    gallery: [["Entregadores celebrando juntos", "Comunidade de verdade"], ["Entregador trabalhando na chuva", "Feito por quem corre"], ["Grupo de entregadores com suas motos", "Todo mundo junto"]],
    faqLabel: "Perguntas frequentes", faqTitleA: "Pergunte.", faqTitleB: "A gente responde.", faqs: [
      ["É seguro? Não é golpe?", "Criptomoedas envolvem risco de perda total. Declarações sobre contrato, liquidez e distribuição precisam de comprovação independente. Confira o painel de transparência e os registros no Solscan; não confie apenas em palavras."],
      ["O que acontece se a capitalização não crescer?", "Continuamos construindo. O projeto não depende só de preço: as parcerias de cashback ajudam a fortalecer a comunidade."],
      ["Preciso investir muito?", "Não. Você pode participar com qualquer valor. Criptomoedas envolvem risco de perda total; use apenas o que pode perder."],
      ["Onde guardo meus tokens?", "Na sua carteira Phantom. Nunca compartilhe senha ou frase secreta, nem mesmo com alguém dizendo ser do projeto."],
      ["E o outro projeto $MOTO?", "É o projeto irmão, criado antes. Cada um segue seu caminho, mas ambos são da mesma família."],
    ],
    communityTitleA: "A cidade roda.", communityTitleB: "A comunidade cresce.", communityText: "Família unida constrói junto: com foco, transparência e a voz da rua. Acompanhe os canais oficiais e fale com a gente quando tiver dúvidas.", officialSite: "Site oficial",
    risk: "Risco:", riskText: "criptomoedas envolvem risco de perda total. Invista apenas o que pode perder.", affiliates: "Afiliados:", affiliatesText: "recebemos comissão em compras feitas pelos links de parceria, sem custo extra para você.", noGuarantee: "Sem garantia:", noGuaranteeText: "não há promessa de lucro. O valor pode subir ou cair.", copyright: "© 2026 MottuCoin. Feito pela comunidade, para a comunidade.",
    imageAlts: { hero: "Entregador pilotando à noite em São Paulo", phone: "Entregador conferindo moedas no celular", future: "Entregador avançando por uma cidade futurista" },
  },
  en: {
    nav: [["Deliveries", "#entregas"], ["Security", "#seguranca"], ["Tokenomics", "#tokenomics"], ["How to buy", "#comprar"], ["Roadmap", "#roadmap"], ["FAQ", "#faq"]],
    buy: "Buy $MOTTU", buyPump: "Buy on Pump.fun", buyPix: "Buy with PIX", viewContract: "View contract",
    menuOpen: "Open menu", menuClose: "Close menu", mainNav: "Main navigation", mobileNav: "Mobile navigation",
    heroPlace: "Born in Rolândia, Brazil", heroKicker: "The currency of those who keep the city moving.",
    heroTitleA: "MottuCoin.", heroTitleB: "Made by us, for us.",
    heroText: "Created by a real delivery rider with over 15 years on the road. Not born in an office: built by someone who works to keep the city moving. Every step supports our people.",
    trust: ["Renounced contract", "Protected liquidity", "No abusive fees", "Buy with PIX"],
    contractEyebrow: "Token contract", contractTitle: "Check it. Copy it. Verify it.", copy: "Copy", copied: "Copied", copyAria: "Copy contract address",
    platforms: [["Pump.fun", "Official page"], ["Solscan", "Full transparency"]],
    securityEyebrow: "Why trust $MOTTU?", securityTitleA: "From the streets.", securityTitleB: "Open for all to see.",
    securityText: "Created on Pump.fun by someone who knows delivery work. Our commitment is organic growth without volume bots or artificial trading. Check the public information before buying.", securityQuote: "“Don't trust words — verify on Solscan.”", openSolscan: "Open Solscan",
    securityItems: [
      ["Bonding curve liquidity", "Created on Pump.fun. Check the current bonding curve and liquidity status on official platforms: this does not remove cryptocurrency risks."],
      ["Official contract", "Check mint and freeze authorities on Solscan. The official address lets you verify the token rather than relying on promises alone."],
      ["Team: 0%", "No team token reserve, according to the project’s declared allocation. Check the public distribution on Solscan."],
    ],
    graduation: "After graduation", graduationText: "Liquidity migration and locking depend on graduation and Pump.fun rules. Verify the current status on the platform; there is no such thing as zero risk.",
    tokenomics: "Tokenomics", tokenTitleA: "Simple.", tokenTitleB: "No tricks.", tokenData: [["Name", "MottuCoin"], ["Symbol", "$MOTTU"], ["Blockchain", "Solana"], ["Team", "0%"]],
    holderTitle: "What holders can take part in", holderBenefits: [
      ["Cashback & shopping", "Shopee, Mercado Livre and Amazon: use the official links. Part of affiliate commissions supports the project; cashback terms depend on each program."],
      ["Fair deliveries", "90% goes to the rider and 10% supports the project and token burns."],
      ["Refer and earn", "5% direct + 2% second level, after a confirmed purchase and 30 days. Selling before 15 days forfeits commission; US$50 monthly cap and Solana wallet confirmation."],
      ["Monthly burn", "1 million $MOTTU on the 1st of each month, with public proof. Reducing supply does not guarantee a higher price."],
    ], familyLabel: "Our community in numbers", familyStats: [["25 million+", "Circulation reported by the project"], ["1 million / month", "Scheduled burn on the 1st"], ["15+ years", "Founder’s experience on the road"]], statsNote: "Circulation is reported by the project, not a verified live count. Check supply, distribution and transactions on Solscan.",
    monthlyBurn: "Scheduled monthly burn", burnAmount: "1,000,000", burnRule: "tokens on the 1st of every month", burnText: "Project-reported target. As of the 10 October 2026 update, the project reports no recorded on-chain burns. Awaiting a supporting transaction.", totalSupply: "Initial total supply", totalSupplyValue: "1 billion", transactionFee: "Transaction fee", feeValue: "2% redistributed",
    howTo: "How to buy", stepsTitle: "PIX or a Solana wallet.", pixTitle: "Option 1 — PIX through the official bot", pixSteps: ["Open the official bot and check the instructions and amount before paying.", "Provide your Solana wallet and make the PIX payment specified by the bot.", "After payment confirmation, check that your wallet received $MOTTU."], walletTitle: "Option 2 — Solana wallet", purchaseCaution: "Purchases and swaps take place on official external platforms. Never share your recovery phrase; check the contract and terms before confirming.", steps: [
      ["01", "Install a wallet", "Create or open a Solana wallet with Phantom or Solflare. Keep your recovery phrase safe and never share it."],
      ["02", "Add funds", "Buy SOL and transfer it to your wallet. Check the address and keep enough SOL for network fees."],
      ["03", "Buy $MOTTU", "Use this site’s official buy or swap buttons. Connect your wallet on the chosen platform and verify the contract before swapping SOL for $MOTTU."],
    ],
    cashback: "Cashback & partnerships", cashbackTitle: "Buy what you use. Strengthen the project.", cashbackText: "Part of the commission goes back into strengthening MottuCoin, at no extra cost to you.",
    stores: [["Shopee", "Everything you need"], ["Mercado Livre", "A wide range of products"], ["Amazon", "Gear and helmets"]], linkSoon: "Link coming soon",
    roadmapLabel: "Roadmap", roadmapTitle: "From the streets to the future.", roadmap: [
      ["Pump.fun launch", "Completed", true], ["Official website + social media", "Completed", true], ["PIX purchase bot", "Completed", true], ["Affiliate cashback", "Active", true],
      ["Permanent liquidity", "In progress", false], ["MottuCoin app", "In development", false], ["Brand partnerships", "Under negotiation", false], ["Listing on other platforms", "When volume is reached", false],
    ],
    gallery: [["Delivery riders celebrating together", "A real community"], ["Delivery rider working in the rain", "Made by those on the road"], ["Delivery riders together with their motorcycles", "Everyone together"]],
    faqLabel: "Frequently asked questions", faqTitleA: "Ask.", faqTitleB: "We answer.", faqs: [
      ["Is it safe? Is it a scam?", "Cryptocurrencies carry a risk of total loss. Claims about contract authorities, liquidity and distribution need independent evidence. Check the transparency panel and Solscan records; do not rely on promises alone."],
      ["What happens if the market cap doesn't grow?", "We keep building. The project isn't driven by price alone: cashback partnerships help strengthen the community."],
      ["Do I need to invest a lot?", "No. You can participate with any amount. Cryptocurrencies carry a risk of total loss; only use what you can afford to lose."],
      ["Where do I keep my tokens?", "In your Phantom wallet. Never share your password or recovery phrase, even with someone claiming to represent the project."],
      ["What about the other $MOTO project?", "It is our sister project, created earlier. Each follows its own path, but both are part of the same family."],
    ],
    communityTitleA: "The city moves.", communityTitleB: "The community grows.", communityText: "A united family builds together with focus, transparency, and the voice of the streets. Follow the official channels and contact us with any questions.", officialSite: "Official website",
    risk: "Risk:", riskText: "cryptocurrencies carry a risk of total loss. Invest only what you can afford to lose.", affiliates: "Affiliates:", affiliatesText: "we receive a commission on purchases made through partner links, at no extra cost to you.", noGuarantee: "No guarantee:", noGuaranteeText: "there is no promise of profit. The value may rise or fall.", copyright: "© 2026 MottuCoin. Made by the community, for the community.",
    imageAlts: { hero: "Delivery rider riding at night in São Paulo", phone: "Delivery rider checking coins on a phone", future: "Delivery rider moving through a futuristic city" },
  },
} as const;

const securityIcons = [LockKeyhole, ShieldCheck, Users];
const stepIcons = [WalletCards, TrendingUp, Bike];
const storeLinks = ["https://s.shopee.com.br/9V1qiP1bKO", "https://meli.la/2VGWNCG", "https://amazon.com.br/?tag=mottucoin-20"];
const galleryImages = [crewAsset.url, rainAsset.url, unityAsset.url];

function BrandMark({ language }: { language: Language }) {
  return (
    <a href="#topo" className="flex items-center gap-2.5" aria-label={language === "pt" ? "MottuCoin — início" : "MottuCoin — home"}>
      <span className="grid size-9 place-items-center border-2 border-primary bg-primary font-display text-lg font-black text-primary-foreground -skew-x-6">
        M
      </span>
      <span className="font-display text-xl font-black uppercase tracking-normal">
        Mottu<span className="text-primary">Coin</span>
      </span>
    </a>
  );
}

function Index() {
  const [copied, setCopied] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [language, setLanguage] = useState<Language>("pt");
  const t = content[language];

  useEffect(() => {
    const saved = window.localStorage.getItem("mottucoin-language");
    if (saved === "en" || saved === "pt") setLanguage(saved);
  }, []);

  useEffect(() => {
    document.documentElement.lang = language === "pt" ? "pt-BR" : "en";
    document.title = language === "pt" ? "MottuCoin | Feito por nós, para nós" : "MottuCoin | Made by us, for us";
    const description = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (description) description.content = language === "pt"
      ? "MottuCoin ($MOTTU) na Solana: feito por um entregador para a comunidade, com compra via PIX, entregas justas e indicações."
      : "MottuCoin ($MOTTU) on Solana: built by a rider for the community, with PIX purchases, fair deliveries and referrals.";
  }, [language]);

  const changeLanguage = (nextLanguage: Language) => {
    setLanguage(nextLanguage);
    window.localStorage.setItem("mottucoin-language", nextLanguage);
  };

  const copyContract = async () => {
    try {
      await navigator.clipboard.writeText(CONTRACT);
    } catch {
      const field = document.createElement("textarea");
      field.value = CONTRACT;
      field.setAttribute("readonly", "");
      field.style.position = "fixed";
      field.style.opacity = "0";
      document.body.appendChild(field);
      field.select();
      document.execCommand("copy");
      field.remove();
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <main id="topo" className="min-h-screen overflow-hidden bg-background text-foreground">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-border/70 bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
          <BrandMark language={language} />
          <nav className="hidden items-center gap-6 lg:flex" aria-label={t.mainNav}>
            {t.nav.map(([label, href]) => <a key={href} href={href} className="text-xs font-bold uppercase text-muted-foreground transition-colors hover:text-primary">{label}</a>)}
          </nav>
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="flex h-10 items-center border border-primary" role="group" aria-label={language === "pt" ? "Selecionar idioma" : "Select language"}>
              {(["pt", "en"] as const).map((option) => (
                <button key={option} type="button" onClick={() => changeLanguage(option)} aria-pressed={language === option} className={`h-full px-2.5 font-mono text-xs font-bold uppercase transition-colors sm:px-3 ${language === option ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-primary"}`}>
                  {option.toUpperCase()}
                </button>
              ))}
            </div>
            <a href={PUMP_URL} target="_blank" rel="noreferrer" className="btn-primary hidden sm:inline-flex">{t.buy} <ArrowRight className="size-4" /></a>
            <button type="button" onClick={() => setMenuOpen((open) => !open)} className="icon-button sm:hidden" aria-label={menuOpen ? t.menuClose : t.menuOpen} aria-expanded={menuOpen}>
              {menuOpen ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </div>
        {menuOpen && <nav className="border-t border-border bg-background px-4 py-4 sm:hidden" aria-label={t.mobileNav}><div className="grid gap-1">
          {t.nav.map(([label, href]) => <a key={href} href={href} onClick={() => setMenuOpen(false)} className="py-3 text-sm font-bold uppercase">{label}</a>)}
          <a href={PUMP_URL} target="_blank" rel="noreferrer" className="btn-primary mt-2">{t.buy} <ArrowRight className="size-4" /></a>
        </div></nav>}
      </header>

      <section className="relative min-h-[92svh] border-b border-border pt-16">
        <img src={nightAsset.url} alt={t.imageAlts.hero} className="absolute inset-0 size-full object-cover object-center" />
        <div className="hero-shade absolute inset-0" />
        <div className="relative mx-auto flex min-h-[calc(92svh-4rem)] max-w-7xl items-end px-4 pb-12 pt-24 sm:px-6 lg:items-center lg:pb-16"><div className="max-w-4xl">
          <div className="mb-5 inline-flex items-center gap-2 border border-primary/50 bg-background/75 px-3 py-2 text-xs font-bold uppercase text-primary backdrop-blur-md"><span className="size-2 animate-pulse rounded-full bg-primary" />{t.heroPlace}</div>
          <p className="mb-3 font-mono text-sm font-bold uppercase text-warning sm:text-base">{t.heroKicker}</p>
          <h1 className="max-w-4xl font-display text-5xl font-black uppercase leading-[0.88] text-hero sm:text-7xl lg:text-8xl">{t.heroTitleA}<br /><span className="text-primary">{t.heroTitleB}</span></h1>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-hero-muted sm:text-lg">{t.heroText}</p>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row"><a href={PUMP_URL} target="_blank" rel="noreferrer" className="btn-primary btn-large">{t.buyPump} <ArrowRight className="size-5" /></a><a href="#contrato" className="btn-ghost btn-large">{t.viewContract} <ChevronDown className="size-5" /></a></div>
          <div className="mt-8 flex flex-wrap gap-x-5 gap-y-2 text-xs font-bold uppercase text-hero-muted">{t.trust.map((item) => <span key={item} className="flex items-center gap-1.5"><CheckCircle2 className="size-4 text-primary" />{item}</span>)}</div>
        </div></div>
      </section>

      <DeliverySection language={language} />

      <section id="contrato" className="border-b border-border bg-surface py-14 sm:py-20"><div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mb-6 flex items-end justify-between gap-4"><div><p className="eyebrow">{t.contractEyebrow}</p><h2 className="section-title">{t.contractTitle}</h2></div><ShieldCheck className="hidden size-12 text-primary sm:block" /></div>
        <div className="contract-bar"><code className="min-w-0 flex-1 overflow-hidden text-ellipsis whitespace-nowrap font-mono text-sm text-foreground sm:text-base">{CONTRACT}</code><button type="button" onClick={copyContract} className="btn-primary shrink-0" aria-label={t.copyAria}>{copied ? <Check className="size-4" /> : <Copy className="size-4" />}<span className="hidden sm:inline">{copied ? t.copied : t.copy}</span></button></div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">{t.platforms.map(([name, label], index) => { const urls = [PUMP_URL, SOLSCAN_URL]; return <a key={name} href={urls[index]} target="_blank" rel="noreferrer" className="platform-link"><span><strong>{name}</strong><small>{label}</small></span><ExternalLink className="size-4 text-primary" /></a>; })}</div>
      </div></section>

      <section id="seguranca" className="border-b border-border py-16 sm:py-24"><div className="mx-auto max-w-7xl px-4 sm:px-6"><div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
        <div><p className="eyebrow">{t.securityEyebrow}</p><h2 className="section-title">{t.securityTitleA}<br />{t.securityTitleB}</h2><p className="mt-5 max-w-xl text-muted-foreground">{t.securityText}</p><blockquote className="mt-8 border-l-4 border-primary pl-5 font-display text-xl font-bold leading-tight sm:text-2xl">{t.securityQuote}</blockquote><a href={SOLSCAN_URL} target="_blank" rel="noreferrer" className="btn-outline mt-6">{t.openSolscan} <ExternalLink className="size-4" /></a></div>
        <div className="grid gap-px border border-border bg-border sm:grid-cols-3 lg:grid-cols-1">{t.securityItems.map(([title, text], index) => { const Icon = securityIcons[index] ?? ShieldCheck; return <article key={title} className="bg-background p-5 sm:p-6 lg:flex lg:items-start lg:gap-5"><span className="mb-5 grid size-11 shrink-0 place-items-center bg-primary text-primary-foreground lg:mb-0"><Icon className="size-5" /></span><div><p className="mb-1 font-mono text-xs font-bold text-primary">0{index + 1}</p><h3 className="font-display text-xl font-bold uppercase">{title}</h3><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{text}</p></div></article>; })}<article className="bg-primary p-5 text-primary-foreground sm:p-6 lg:flex lg:items-center lg:gap-5"><Flame className="mb-4 size-10 shrink-0 lg:mb-0" /><div><h3 className="font-display text-xl font-black uppercase">{t.graduation}</h3><p className="mt-1 text-sm font-semibold">{t.graduationText}</p></div></article></div>
      </div></div></section>

      <section id="tokenomics" className="border-b border-border bg-surface py-16 sm:py-24"><div className="mx-auto max-w-7xl px-4 sm:px-6"><p className="eyebrow">{t.tokenomics}</p><div className="grid gap-10 lg:grid-cols-2 lg:items-end">
        <div><h2 className="section-title">{t.tokenTitleA}<br />{t.tokenTitleB}</h2><div className="mt-8 grid grid-cols-2 gap-px border border-border bg-border">{t.tokenData.map(([label, value]) => <div key={label} className="bg-background p-4 sm:p-5"><p className="text-xs uppercase text-muted-foreground">{label}</p><p className="mt-1 font-display text-xl font-black uppercase sm:text-2xl">{value}</p></div>)}</div></div>
        <div className="border border-primary/40 bg-background p-6 sm:p-8"><div className="flex items-center justify-between"><Flame className="size-9 text-warning" /><span className="status-chip">{t.monthlyBurn}</span></div><p className="mt-7 font-display text-5xl font-black leading-none text-primary sm:text-6xl">{t.burnAmount}</p><p className="mt-2 text-sm font-bold uppercase">{t.burnRule}</p><p className="mt-5 text-sm leading-relaxed text-muted-foreground">{t.burnText}</p><div className="mt-6 flex items-center justify-between border-t border-border pt-5 text-sm"><span className="text-muted-foreground">{t.totalSupply}</span><strong>{t.totalSupplyValue}</strong></div><div className="mt-3 flex items-center justify-between text-sm"><span className="text-muted-foreground">{t.transactionFee}</span><strong>{t.feeValue}</strong></div></div>
      </div>
        <div className="mt-14 border-t border-border pt-10"><h3 className="font-display text-3xl font-black uppercase">{t.holderTitle}</h3><div className="mt-6 grid gap-6 sm:grid-cols-2">{t.holderBenefits.map(([title, text]) => <article key={title} className="border-l-2 border-primary pl-4"><h4 className="font-display text-xl font-bold uppercase text-primary">{title}</h4><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{text}</p></article>)}</div></div>
        <div className="mt-12 border-t border-border pt-8"><p className="eyebrow">{t.familyLabel}</p><dl className="mt-5 grid gap-6 sm:grid-cols-3">{t.familyStats.map(([value, label]) => <div key={label}><dt className="text-xs uppercase text-muted-foreground">{label}</dt><dd className="mt-2 font-display text-3xl font-black text-primary">{value}</dd></div>)}</dl><p className="mt-5 max-w-3xl text-xs leading-relaxed text-muted-foreground">{t.statsNote}</p></div>
      </div></section>

      <MarketSwap language={language} />


      <section className="relative border-b border-border py-16 sm:py-24"><img src={phoneAsset.url} alt={t.imageAlts.phone} className="absolute inset-0 size-full object-cover object-center" /><div className="section-shade absolute inset-0" /><div className="relative mx-auto max-w-7xl px-4 sm:px-6"><div className="max-w-3xl"><p className="eyebrow">{t.howTo}</p><h2 className="section-title text-hero">{t.stepsTitle}</h2></div><div className="mt-9 border-y border-hero-muted/30 py-7"><h3 className="font-display text-2xl font-bold uppercase text-primary">{t.pixTitle}</h3><ol className="mt-5 grid gap-5 lg:grid-cols-3">{t.pixSteps.map((text, index) => <li key={text} className="flex items-start gap-3 text-sm leading-relaxed text-hero-muted"><span className="font-mono font-bold text-primary">0{index + 1}</span><span>{text}</span></li>)}</ol><a href="https://t.me/MottuPixPay_Bot" target="_blank" rel="noreferrer" className="btn-primary mt-6">{t.buyPix} <ExternalLink className="size-4" /></a></div><h3 className="mt-9 font-display text-2xl font-bold uppercase text-primary">{t.walletTitle}</h3><div className="mt-5 grid gap-3 lg:grid-cols-3">{t.steps.map(([step, title, text], index) => { const Icon = stepIcons[index] ?? WalletCards; return <article key={step} className="step-card"><div className="flex items-center justify-between"><Icon className="size-7 text-primary" /><span className="font-mono text-sm font-bold text-primary">{step}</span></div><h3 className="mt-12 font-display text-2xl font-black uppercase">{title}</h3><p className="mt-3 text-sm leading-relaxed text-hero-muted">{text}</p></article>; })}</div><div className="mt-6 flex flex-col gap-3 sm:flex-row"><a href={PUMP_URL} target="_blank" rel="noreferrer" className="btn-primary btn-large">{t.buyPump} <ArrowRight className="size-5" /></a><a href="https://t.me/MottuPixPay_Bot" target="_blank" rel="noreferrer" className="btn-ghost btn-large">{t.buyPix} <ExternalLink className="size-4" /></a></div><p className="mt-5 max-w-3xl text-xs leading-relaxed text-hero-muted">{t.purchaseCaution}</p></div></section>

      <section className="border-b border-border bg-surface py-16 sm:py-24"><div className="mx-auto max-w-7xl px-4 sm:px-6"><div className="grid gap-8 lg:grid-cols-[1fr_1.2fr] lg:items-center"><div><p className="eyebrow">{t.cashback}</p><h2 className="section-title">{t.cashbackTitle}</h2><p className="mt-5 text-muted-foreground">{t.cashbackText}</p></div><div className="grid gap-3 sm:grid-cols-2">{t.stores.map(([store, detail], index) => <a key={store} href={storeLinks[index]} target="_blank" rel="noreferrer" className="partner-link"><ShoppingBag className="size-5 text-primary" /><span className="flex-1"><strong>{store}</strong><small>{detail}</small></span><ExternalLink className="size-4" /></a>)}<div className="partner-link opacity-70"><Bike className="size-5 text-primary" /><span className="flex-1"><strong>Mottu</strong><small>{t.linkSoon}</small></span></div></div></div></div></section>

      <section id="roadmap" className="border-b border-border py-16 sm:py-24"><div className="mx-auto max-w-7xl px-4 sm:px-6"><p className="eyebrow">{t.roadmapLabel}</p><h2 className="section-title">{t.roadmapTitle}</h2><div className="mt-10 grid gap-8 lg:grid-cols-[1.05fr_0.95fr]"><div className="space-y-px bg-border">{t.roadmap.map(([title, status, done], index) => <div key={String(title)} className="flex items-center gap-4 bg-background px-4 py-4 sm:px-5"><span className={`grid size-8 shrink-0 place-items-center border ${done ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground"}`}>{done ? <Check className="size-4" /> : <span className="font-mono text-xs">{index + 1}</span>}</span><strong className="min-w-0 flex-1 text-sm">{title}</strong><span className={done ? "status-chip" : "text-right text-xs text-muted-foreground"}>{status}</span></div>)}</div><img src={futureAsset.url} alt={t.imageAlts.future} className="h-full min-h-[430px] w-full border border-border object-cover" /></div></div></section>

      <section className="border-b border-border bg-surface py-16 sm:py-24"><div className="mx-auto max-w-7xl px-4 sm:px-6"><div className="grid gap-4 sm:grid-cols-3">{t.gallery.map(([alt, label], index) => <figure key={label} className="group relative aspect-[4/5] overflow-hidden border border-border"><img src={galleryImages[index]} alt={alt} className="size-full object-cover transition-transform duration-500 group-hover:scale-105" /><div className="photo-shade absolute inset-0" /><figcaption className="absolute inset-x-0 bottom-0 p-5 font-display text-xl font-black uppercase text-hero">{label}</figcaption></figure>)}</div></div></section>

      <section id="faq" className="border-b border-border py-16 sm:py-24"><div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[0.75fr_1.25fr]"><div><p className="eyebrow">{t.faqLabel}</p><h2 className="section-title">{t.faqTitleA}<br />{t.faqTitleB}</h2></div><div className="divide-y divide-border border-y border-border">{t.faqs.map(([question, answer]) => <details key={question} className="group py-5"><summary className="flex cursor-pointer list-none items-center justify-between gap-5 font-display text-lg font-bold uppercase"><span>{question}</span><ChevronDown className="size-5 shrink-0 text-primary transition-transform group-open:rotate-180" /></summary><p className="max-w-2xl pt-4 text-sm leading-relaxed text-muted-foreground">{answer}</p></details>)}</div></div></section>

      <CommunityReferral language={language} />

      <TransparencySection language={language} />

      <section className="bg-primary py-16 text-primary-foreground sm:py-20"><div className="mx-auto max-w-7xl px-4 text-center sm:px-6"><Bike className="mx-auto size-10" /><h2 className="mx-auto mt-5 max-w-4xl font-display text-4xl font-black uppercase leading-[0.95] sm:text-6xl">{t.communityTitleA}<br />{t.communityTitleB}</h2><p className="mx-auto mt-5 max-w-xl font-semibold">{t.communityText}</p><div className="mt-8 flex flex-wrap justify-center gap-3"><a href="https://t.me/mottucoin_official" target="_blank" rel="noreferrer" className="btn-on-primary">Telegram <ExternalLink className="size-4" /></a><a href="https://x.com/mottucoin" target="_blank" rel="noreferrer" className="btn-on-primary">X / Twitter <ExternalLink className="size-4" /></a><a href="https://t.me/MottuPixPay_Bot" target="_blank" rel="noreferrer" className="btn-on-primary">Bot PIX <ExternalLink className="size-4" /></a></div></div></section>

      <footer className="bg-footer py-10 text-footer-foreground"><div className="mx-auto max-w-7xl px-4 sm:px-6"><div className="flex flex-col justify-between gap-8 border-b border-footer-border pb-8 sm:flex-row sm:items-center"><BrandMark language={language} /><div className="flex gap-5 text-xs font-bold uppercase text-footer-muted"><a href={SOLSCAN_URL}>Solscan</a><a href={PUMP_URL}>Pump.fun</a></div></div><div className="grid gap-5 py-8 text-xs leading-relaxed text-footer-muted md:grid-cols-3"><p><strong className="text-footer-foreground">{t.risk}</strong> {t.riskText}</p><p><strong className="text-footer-foreground">{t.affiliates}</strong> {t.affiliatesText}</p><p><strong className="text-footer-foreground">{t.noGuarantee}</strong> {t.noGuaranteeText}</p></div><p className="border-t border-footer-border pt-6 text-xs text-footer-muted">{t.copyright}</p></div></footer>
    </main>
  );
}
