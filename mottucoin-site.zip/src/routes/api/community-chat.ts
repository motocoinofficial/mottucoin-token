import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/community-chat")({
  server: { handlers: {
    GET: async ({ request }) => {
      const { readCommunityChat } = await import("@/lib/transparency-chat.server");
      return readCommunityChat(request);
    },
    POST: async ({ request }) => {
      const { answerCommunityChat } = await import("@/lib/transparency-chat.server");
      return answerCommunityChat(request);
    },
  } },
});