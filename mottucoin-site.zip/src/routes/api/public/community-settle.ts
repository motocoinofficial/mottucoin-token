import { createFileRoute } from "@tanstack/react-router";
import { authenticateCronRequest } from "@/integrations/supabase/cron-auth";

export const Route = createFileRoute("/api/public/community-settle")({
  server: { handlers: { POST: async ({ request }) => {
    const denied = await authenticateCronRequest(request);
    if (denied) return denied;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { settleMemberCommissions } = await import("@/lib/community-chain.server");
    const { data: rows, error } = await supabaseAdmin.from("community_commissions").select("beneficiary_id").eq("status", "pending").order("hold_until").limit(100);
    if (error) return Response.json({ error: "Settlement unavailable" }, { status: 503 });
    const results = [];
    for (const id of new Set((rows ?? []).map((row) => row.beneficiary_id))) results.push(await settleMemberCommissions(id));
    return Response.json({ checked: results.reduce((sum, row) => sum + row.checked, 0) }, { headers: { "Cache-Control": "no-store" } });
  } } },
});