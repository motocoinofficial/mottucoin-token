export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      community_ai_state: {
        Row: {
          id: string
          paused: boolean
          reason: string | null
          status: number | null
          updated_at: string
        }
        Insert: {
          id: string
          paused?: boolean
          reason?: string | null
          status?: number | null
          updated_at?: string
        }
        Update: {
          id?: string
          paused?: boolean
          reason?: string | null
          status?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      community_commissions: {
        Row: {
          beneficiary_id: string
          commission_rate: number
          commission_usd: number
          created_at: string
          forfeiture_reason: string | null
          hold_until: string
          id: string
          mottu_amount: number
          paid_at: string | null
          purchase_amount_usd: number
          qualifying_purchase_at: string
          referral_level: number
          sell_lock_until: string
          source: string
          source_member_id: string
          source_reference: string
          status: string
          updated_at: string
        }
        Insert: {
          beneficiary_id: string
          commission_rate: number
          commission_usd: number
          created_at?: string
          forfeiture_reason?: string | null
          hold_until: string
          id?: string
          mottu_amount: number
          paid_at?: string | null
          purchase_amount_usd: number
          qualifying_purchase_at: string
          referral_level: number
          sell_lock_until: string
          source: string
          source_member_id: string
          source_reference: string
          status?: string
          updated_at?: string
        }
        Update: {
          beneficiary_id?: string
          commission_rate?: number
          commission_usd?: number
          created_at?: string
          forfeiture_reason?: string | null
          hold_until?: string
          id?: string
          mottu_amount?: number
          paid_at?: string | null
          purchase_amount_usd?: number
          qualifying_purchase_at?: string
          referral_level?: number
          sell_lock_until?: string
          source?: string
          source_member_id?: string
          source_reference?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_commissions_beneficiary_id_fkey"
            columns: ["beneficiary_id"]
            isOneToOne: false
            referencedRelation: "community_members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "community_commissions_source_member_id_fkey"
            columns: ["source_member_id"]
            isOneToOne: false
            referencedRelation: "community_members"
            referencedColumns: ["id"]
          },
        ]
      }
      community_members: {
        Row: {
          access_secret_hash: string
          created_at: string
          device_hash: string
          id: string
          ip_hash: string
          network_referrer_id: string | null
          referral_code: string
          referred_by: string | null
          rules_accepted_at: string
          rules_version: string
          solana_wallet: string | null
          updated_at: string
          wallet_verified_at: string | null
        }
        Insert: {
          access_secret_hash: string
          created_at?: string
          device_hash: string
          id?: string
          ip_hash: string
          network_referrer_id?: string | null
          referral_code?: string
          referred_by?: string | null
          rules_accepted_at: string
          rules_version: string
          solana_wallet?: string | null
          updated_at?: string
          wallet_verified_at?: string | null
        }
        Update: {
          access_secret_hash?: string
          created_at?: string
          device_hash?: string
          id?: string
          ip_hash?: string
          network_referrer_id?: string | null
          referral_code?: string
          referred_by?: string | null
          rules_accepted_at?: string
          rules_version?: string
          solana_wallet?: string | null
          updated_at?: string
          wallet_verified_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "community_members_network_referrer_id_fkey"
            columns: ["network_referrer_id"]
            isOneToOne: false
            referencedRelation: "community_members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "community_members_referred_by_fkey"
            columns: ["referred_by"]
            isOneToOne: false
            referencedRelation: "community_members"
            referencedColumns: ["id"]
          },
        ]
      }
      community_referral_visits: {
        Row: {
          converted_member_id: string | null
          created_at: string
          device_hash: string
          eligible: boolean
          id: string
          ineligible_reason: string | null
          ip_hash: string
          referral_code: string
          referrer_id: string
        }
        Insert: {
          converted_member_id?: string | null
          created_at?: string
          device_hash: string
          eligible?: boolean
          id?: string
          ineligible_reason?: string | null
          ip_hash: string
          referral_code: string
          referrer_id: string
        }
        Update: {
          converted_member_id?: string | null
          created_at?: string
          device_hash?: string
          eligible?: boolean
          id?: string
          ineligible_reason?: string | null
          ip_hash?: string
          referral_code?: string
          referrer_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_referral_visits_converted_member_id_fkey"
            columns: ["converted_member_id"]
            isOneToOne: false
            referencedRelation: "community_members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "community_referral_visits_referrer_id_fkey"
            columns: ["referrer_id"]
            isOneToOne: false
            referencedRelation: "community_members"
            referencedColumns: ["id"]
          },
        ]
      }
      community_transparency_chats: {
        Row: {
          lease_id: string | null
          lease_until: string | null
          member_id: string
          messages: Json
          requests_day: string
          requests_today: number
          updated_at: string
        }
        Insert: {
          lease_id?: string | null
          lease_until?: string | null
          member_id: string
          messages?: Json
          requests_day?: string
          requests_today?: number
          updated_at?: string
        }
        Update: {
          lease_id?: string | null
          lease_until?: string | null
          member_id?: string
          messages?: Json
          requests_day?: string
          requests_today?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_transparency_chats_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: true
            referencedRelation: "community_members"
            referencedColumns: ["id"]
          },
        ]
      }
      community_wallet_challenges: {
        Row: {
          created_at: string
          expires_at: string
          id: string
          member_id: string
          message: string
          used_at: string | null
          wallet: string
        }
        Insert: {
          created_at?: string
          expires_at: string
          id?: string
          member_id: string
          message: string
          used_at?: string | null
          wallet: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          id?: string
          member_id?: string
          message?: string
          used_at?: string | null
          wallet?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_wallet_challenges_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "community_members"
            referencedColumns: ["id"]
          },
        ]
      }
      delivery_events: {
        Row: {
          created_at: string
          id: string
          message_en: string
          message_pt: string
          order_id: string
          status: Database["public"]["Enums"]["delivery_status"]
        }
        Insert: {
          created_at?: string
          id?: string
          message_en: string
          message_pt: string
          order_id: string
          status: Database["public"]["Enums"]["delivery_status"]
        }
        Update: {
          created_at?: string
          id?: string
          message_en?: string
          message_pt?: string
          order_id?: string
          status?: Database["public"]["Enums"]["delivery_status"]
        }
        Relationships: [
          {
            foreignKeyName: "delivery_events_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "delivery_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      delivery_orders: {
        Row: {
          accepted_at: string | null
          city: string
          created_at: string
          customer_name: string
          customer_phone: string
          delivered_at: string | null
          delivery_address: string
          id: string
          item_description: string
          on_the_way_at: string | null
          payment_method: Database["public"]["Enums"]["delivery_payment_method"]
          pickup_address: string
          proposed_amount: number | null
          rider_id: string | null
          rider_name: string | null
          status: Database["public"]["Enums"]["delivery_status"]
          tracking_code: string
          tracking_secret_hash: string
          updated_at: string
        }
        Insert: {
          accepted_at?: string | null
          city: string
          created_at?: string
          customer_name: string
          customer_phone: string
          delivered_at?: string | null
          delivery_address: string
          id?: string
          item_description: string
          on_the_way_at?: string | null
          payment_method: Database["public"]["Enums"]["delivery_payment_method"]
          pickup_address: string
          proposed_amount?: number | null
          rider_id?: string | null
          rider_name?: string | null
          status?: Database["public"]["Enums"]["delivery_status"]
          tracking_code?: string
          tracking_secret_hash: string
          updated_at?: string
        }
        Update: {
          accepted_at?: string | null
          city?: string
          created_at?: string
          customer_name?: string
          customer_phone?: string
          delivered_at?: string | null
          delivery_address?: string
          id?: string
          item_description?: string
          on_the_way_at?: string | null
          payment_method?: Database["public"]["Enums"]["delivery_payment_method"]
          pickup_address?: string
          proposed_amount?: number | null
          rider_id?: string | null
          rider_name?: string | null
          status?: Database["public"]["Enums"]["delivery_status"]
          tracking_code?: string
          tracking_secret_hash?: string
          updated_at?: string
        }
        Relationships: []
      }
      rider_applications: {
        Row: {
          approval_status: Database["public"]["Enums"]["rider_approval_status"]
          availability: string
          city_region: string
          created_at: string
          id: string
          name: string
          phone: string
          updated_at: string
          user_id: string
          vehicle: string
        }
        Insert: {
          approval_status?: Database["public"]["Enums"]["rider_approval_status"]
          availability: string
          city_region: string
          created_at?: string
          id?: string
          name: string
          phone: string
          updated_at?: string
          user_id: string
          vehicle: string
        }
        Update: {
          approval_status?: Database["public"]["Enums"]["rider_approval_status"]
          availability?: string
          city_region?: string
          created_at?: string
          id?: string
          name?: string
          phone?: string
          updated_at?: string
          user_id?: string
          vehicle?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      begin_community_chat: {
        Args: { p_lease: string; p_member: string }
        Returns: Json
      }
      confirm_community_wallet: {
        Args: { p_challenge: string; p_member: string }
        Returns: undefined
      }
      record_community_purchase: {
        Args: {
          p_at: string
          p_member: string
          p_signature: string
          p_tokens: number
          p_usd: number
        }
        Returns: number
      }
    }
    Enums: {
      delivery_payment_method: "pix" | "mottucoin"
      delivery_status: "sent" | "accepted" | "on_the_way" | "delivered"
      rider_approval_status: "pending" | "approved" | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      delivery_payment_method: ["pix", "mottucoin"],
      delivery_status: ["sent", "accepted", "on_the_way", "delivered"],
      rider_approval_status: ["pending", "approved", "rejected"],
    },
  },
} as const
