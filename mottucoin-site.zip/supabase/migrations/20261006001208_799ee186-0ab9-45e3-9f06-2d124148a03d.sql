CREATE TYPE public.rider_approval_status AS ENUM ('pending', 'approved', 'rejected');
CREATE TYPE public.delivery_status AS ENUM ('sent', 'accepted', 'on_the_way', 'delivered');
CREATE TYPE public.delivery_payment_method AS ENUM ('pix', 'mottucoin');

CREATE TABLE public.rider_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  name text NOT NULL CHECK (char_length(name) BETWEEN 2 AND 100),
  phone text NOT NULL CHECK (char_length(phone) BETWEEN 8 AND 20),
  city_region text NOT NULL CHECK (char_length(city_region) BETWEEN 2 AND 120),
  vehicle text NOT NULL CHECK (char_length(vehicle) BETWEEN 2 AND 80),
  availability text NOT NULL CHECK (char_length(availability) BETWEEN 2 AND 200),
  approval_status public.rider_approval_status NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.rider_applications TO authenticated;
GRANT ALL ON public.rider_applications TO service_role;
ALTER TABLE public.rider_applications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Riders can read their own application" ON public.rider_applications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "Riders can create their own application" ON public.rider_applications FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND approval_status = 'pending');
CREATE POLICY "Riders can update pending application" ON public.rider_applications FOR UPDATE TO authenticated USING (user_id = auth.uid() AND approval_status = 'pending') WITH CHECK (user_id = auth.uid() AND approval_status = 'pending');

CREATE TABLE public.delivery_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tracking_code text NOT NULL UNIQUE DEFAULT upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10)),
  tracking_secret_hash text NOT NULL,
  customer_name text NOT NULL CHECK (char_length(customer_name) BETWEEN 2 AND 100),
  customer_phone text NOT NULL CHECK (char_length(customer_phone) BETWEEN 8 AND 20),
  city text NOT NULL CHECK (char_length(city) BETWEEN 2 AND 100),
  pickup_address text NOT NULL CHECK (char_length(pickup_address) BETWEEN 5 AND 300),
  delivery_address text NOT NULL CHECK (char_length(delivery_address) BETWEEN 5 AND 300),
  item_description text NOT NULL CHECK (char_length(item_description) BETWEEN 2 AND 500),
  proposed_amount numeric(10,2) CHECK (proposed_amount IS NULL OR proposed_amount > 0),
  payment_method public.delivery_payment_method NOT NULL,
  status public.delivery_status NOT NULL DEFAULT 'sent',
  rider_id uuid,
  rider_name text,
  accepted_at timestamptz,
  on_the_way_at timestamptz,
  delivered_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE ON public.delivery_orders TO authenticated;
GRANT ALL ON public.delivery_orders TO service_role;
ALTER TABLE public.delivery_orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Approved riders can see available orders" ON public.delivery_orders FOR SELECT TO authenticated USING (
  (status = 'sent' AND EXISTS (SELECT 1 FROM public.rider_applications r WHERE r.user_id = auth.uid() AND r.approval_status = 'approved'))
  OR rider_id = auth.uid()
);
CREATE POLICY "Assigned riders can update orders" ON public.delivery_orders FOR UPDATE TO authenticated USING (rider_id = auth.uid()) WITH CHECK (rider_id = auth.uid());

CREATE TABLE public.delivery_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.delivery_orders(id) ON DELETE CASCADE,
  status public.delivery_status NOT NULL,
  message_pt text NOT NULL CHECK (char_length(message_pt) BETWEEN 2 AND 240),
  message_en text NOT NULL CHECK (char_length(message_en) BETWEEN 2 AND 240),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.delivery_events TO authenticated;
GRANT ALL ON public.delivery_events TO service_role;
ALTER TABLE public.delivery_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Assigned riders can read delivery events" ON public.delivery_events FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.delivery_orders o WHERE o.id = order_id AND o.rider_id = auth.uid()));

CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER rider_applications_updated_at BEFORE UPDATE ON public.rider_applications FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER delivery_orders_updated_at BEFORE UPDATE ON public.delivery_orders FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

ALTER PUBLICATION supabase_realtime ADD TABLE public.delivery_orders;
ALTER PUBLICATION supabase_realtime ADD TABLE public.delivery_events;