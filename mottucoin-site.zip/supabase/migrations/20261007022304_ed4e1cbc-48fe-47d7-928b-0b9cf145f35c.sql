ALTER TABLE public.community_members ADD COLUMN wallet_verified_at timestamptz;
CREATE UNIQUE INDEX community_members_unique_wallet ON public.community_members(solana_wallet) WHERE solana_wallet IS NOT NULL;
CREATE TABLE public.community_wallet_challenges (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), member_id uuid NOT NULL REFERENCES public.community_members(id) ON DELETE CASCADE,
 wallet text NOT NULL, message text NOT NULL, expires_at timestamptz NOT NULL, used_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.community_wallet_challenges TO service_role;
ALTER TABLE public.community_wallet_challenges ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service manages wallet challenges" ON public.community_wallet_challenges FOR ALL TO service_role USING(true) WITH CHECK(true);
CREATE OR REPLACE FUNCTION public.confirm_community_wallet(p_member uuid, p_challenge uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE c public.community_wallet_challenges;
BEGIN
 SELECT * INTO c FROM public.community_wallet_challenges WHERE id=p_challenge AND member_id=p_member FOR UPDATE;
 IF c.id IS NULL OR c.used_at IS NOT NULL OR c.expires_at<=now() THEN RAISE EXCEPTION 'Invalid or expired challenge'; END IF;
 IF EXISTS(SELECT 1 FROM public.community_commissions WHERE source_member_id=p_member) AND EXISTS(SELECT 1 FROM public.community_members WHERE id=p_member AND solana_wallet IS DISTINCT FROM c.wallet) THEN RAISE EXCEPTION 'Wallet locked by purchase history'; END IF;
 UPDATE public.community_members SET solana_wallet=c.wallet,wallet_verified_at=now() WHERE id=p_member;
 UPDATE public.community_wallet_challenges SET used_at=now() WHERE id=c.id;
END $$;
REVOKE ALL ON FUNCTION public.confirm_community_wallet(uuid,uuid) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.confirm_community_wallet(uuid,uuid) TO service_role;
CREATE OR REPLACE FUNCTION public.record_community_purchase(p_member uuid,p_signature text,p_usd numeric,p_tokens numeric,p_at timestamptz)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE m public.community_members; beneficiary uuid; level integer; rate numeric; used numeric; amount numeric; total integer:=0; month_start timestamptz;
BEGIN
 IF p_usd<=0 OR p_tokens<=0 OR p_at>now() THEN RAISE EXCEPTION 'Invalid purchase'; END IF;
 SELECT * INTO m FROM public.community_members WHERE id=p_member FOR UPDATE;
 IF m.id IS NULL OR m.wallet_verified_at IS NULL OR p_at<m.wallet_verified_at OR p_at<m.rules_accepted_at THEN RAISE EXCEPTION 'Purchase predates wallet confirmation'; END IF;
 month_start:=date_trunc('month',p_at AT TIME ZONE 'UTC') AT TIME ZONE 'UTC';
 FOR level IN 1..2 LOOP
  beneficiary:=CASE WHEN level=1 THEN m.referred_by ELSE m.network_referrer_id END;
  rate:=CASE WHEN level=1 THEN 0.05 ELSE 0.02 END;
  IF beneficiary IS NULL THEN CONTINUE; END IF;
  PERFORM 1 FROM public.community_members WHERE id=beneficiary FOR UPDATE;
  IF EXISTS(SELECT 1 FROM public.community_commissions WHERE source='token' AND source_reference=p_signature AND beneficiary_id=beneficiary AND referral_level=level) THEN CONTINUE; END IF;
  SELECT coalesce(sum(commission_usd),0) INTO used FROM public.community_commissions WHERE beneficiary_id=beneficiary AND qualifying_purchase_at>=month_start AND qualifying_purchase_at<month_start+interval '1 month';
  amount:=least(greatest(50-used,0),round(p_usd*rate,2));
  INSERT INTO public.community_commissions(beneficiary_id,source_member_id,source,source_reference,referral_level,commission_rate,purchase_amount_usd,commission_usd,mottu_amount,qualifying_purchase_at,hold_until,sell_lock_until)
  VALUES(beneficiary,p_member,'token',p_signature,level,rate,p_usd,amount,p_tokens*amount/p_usd,p_at,p_at+interval '30 days',p_at+interval '15 days');
  total:=total+1;
 END LOOP;
 RETURN total;
END $$;
REVOKE ALL ON FUNCTION public.record_community_purchase(uuid,text,numeric,numeric,timestamptz) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.record_community_purchase(uuid,text,numeric,numeric,timestamptz) TO service_role;