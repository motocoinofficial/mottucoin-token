CREATE TABLE public.community_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referral_code text NOT NULL UNIQUE DEFAULT upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10)),
  access_secret_hash text NOT NULL UNIQUE,
  referred_by uuid REFERENCES public.community_members(id) ON DELETE SET NULL,
  network_referrer_id uuid REFERENCES public.community_members(id) ON DELETE SET NULL,
  rules_version text NOT NULL,
  rules_accepted_at timestamptz NOT NULL,
  solana_wallet text,
  device_hash text NOT NULL UNIQUE,
  ip_hash text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT community_members_wallet_format CHECK (solana_wallet IS NULL OR solana_wallet ~ '^[1-9A-HJ-NP-Za-km-z]{32,44}$'),
  CONSTRAINT community_members_no_self_referral CHECK (referred_by IS NULL OR referred_by <> id),
  CONSTRAINT community_members_no_self_network CHECK (network_referrer_id IS NULL OR network_referrer_id <> id)
);
GRANT ALL ON public.community_members TO service_role;
ALTER TABLE public.community_members ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.community_referral_visits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid NOT NULL REFERENCES public.community_members(id) ON DELETE CASCADE,
  referral_code text NOT NULL,
  device_hash text NOT NULL,
  ip_hash text NOT NULL,
  eligible boolean NOT NULL DEFAULT false,
  ineligible_reason text,
  converted_member_id uuid REFERENCES public.community_members(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.community_referral_visits TO service_role;
ALTER TABLE public.community_referral_visits ENABLE ROW LEVEL SECURITY;
CREATE INDEX community_referral_visits_referrer_created_idx ON public.community_referral_visits(referrer_id, created_at DESC);
CREATE INDEX community_referral_visits_device_idx ON public.community_referral_visits(device_hash);
CREATE INDEX community_referral_visits_ip_idx ON public.community_referral_visits(ip_hash);

CREATE TABLE public.community_commissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  beneficiary_id uuid NOT NULL REFERENCES public.community_members(id) ON DELETE CASCADE,
  source_member_id uuid NOT NULL REFERENCES public.community_members(id) ON DELETE CASCADE,
  source text NOT NULL CHECK (source IN ('token', 'pix', 'partner')),
  source_reference text NOT NULL,
  referral_level smallint NOT NULL CHECK (referral_level IN (1, 2)),
  commission_rate numeric(5,4) NOT NULL CHECK (commission_rate IN (0.0500, 0.0200)),
  purchase_amount_usd numeric(14,2) NOT NULL CHECK (purchase_amount_usd > 0),
  commission_usd numeric(10,2) NOT NULL CHECK (commission_usd >= 0 AND commission_usd <= 50),
  mottu_amount numeric(24,6) NOT NULL CHECK (mottu_amount >= 0),
  qualifying_purchase_at timestamptz NOT NULL,
  hold_until timestamptz NOT NULL,
  sell_lock_until timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'available', 'forfeited', 'paid')),
  forfeiture_reason text,
  paid_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (source, source_reference, referral_level, beneficiary_id)
);
GRANT ALL ON public.community_commissions TO service_role;
ALTER TABLE public.community_commissions ENABLE ROW LEVEL SECURITY;
CREATE INDEX community_commissions_beneficiary_created_idx ON public.community_commissions(beneficiary_id, created_at DESC);
CREATE INDEX community_commissions_release_idx ON public.community_commissions(status, hold_until);

CREATE TRIGGER community_members_updated_at BEFORE UPDATE ON public.community_members FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER community_commissions_updated_at BEFORE UPDATE ON public.community_commissions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();