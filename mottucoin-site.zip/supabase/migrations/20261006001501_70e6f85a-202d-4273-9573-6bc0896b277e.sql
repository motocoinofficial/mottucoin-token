DROP POLICY IF EXISTS "Assigned riders can update orders" ON public.delivery_orders;
REVOKE UPDATE ON public.delivery_orders FROM authenticated;
REVOKE UPDATE ON public.rider_applications FROM authenticated;
DROP POLICY IF EXISTS "Riders can update pending application" ON public.rider_applications;