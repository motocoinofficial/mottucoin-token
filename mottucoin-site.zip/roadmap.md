# MottuCoin site

- [ ] Add private single-conversation member AI chat with saved history, cited sources and on-chain/declaration distinction

- [x] Add the bilingual transparency panel and community FAQ, distinguishing supplied claims from verified evidence and preserving existing links

- [x] Update PT/EN founder, trust, purchase and holder-benefit copy; preserve monthly burn and working links

- [x] Apply the urban MottuCoin design system
- [x] Add supplied rider imagery
- [x] Build contract, security, tokenomics, chart, buying, partnerships, roadmap, FAQ, community, and legal sections
- [x] Connect official external links and contract copy action
- [x] Add route metadata and responsive navigation
- [x] Add complete PT-BR / English translation with a persistent header selector
- [x] Add the MottuCoin Deliveries public section without changing existing content
- [x] Build customer order, rider registration, delivery workflow, tracking, and notifications
- [x] Add installable mobile app support and a visible install action
- [x] Add live $MOTTU price, swap actions, and market verification links
- [ ] Add automatic community referral links, rule acceptance, antifraud checks, and commission tracking
- [x] Remove all DexScreener navigation links and embeds without changing other working buttons
- [ ] Confirm Solana wallet ownership and purchases; enforce commission timing, early-sale forfeiture, and the monthly cap
