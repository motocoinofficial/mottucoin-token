<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the public experience as a single-page, section-based site because all primary calls to action belong to one continuous trust and purchase journey.
- Store delivery requests and rider applications in Lovable Cloud with server-validated workflow changes because operational data must persist securely across devices.
- Fetch public token market data directly from DexScreener and keep purchases on established external platforms because the site must never custody wallets or funds.
- Keep community credentials hashed and private; server-only signature verification and finalized chain reads authorize wallet and commission changes because client declarations are not proof.
- Serialize monthly commission allocations in a service-only database function because concurrent purchases must not exceed the monthly cap.
- Release commissions only after a complete verified sale-window scan, on dashboard reads or an authenticated settlement callback, because missing chain data must fail closed.
- Keep dated transparency statements in a bilingual presentation-only section and distinguish supplied claims from independent verification because static copy is not blockchain evidence.
