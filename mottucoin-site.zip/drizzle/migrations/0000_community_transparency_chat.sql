CREATE TABLE public.community_transparency_chats (
 member_id uuid PRIMARY KEY REFERENCES public.community_members(id) ON DELETE CASCADE,
 messages jsonb NOT NULL DEFAULT '[]'::jsonb,
 lease_id uuid,
 lease_until timestamptz,
 requests_day date NOT NULL DEFAULT CURRENT_DATE,
 requests_today integer NOT NULL DEFAULT 0,
 updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.community_transparency_chats TO service_role;
ALTER TABLE public.community_transparency_chats ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_only_chat ON public.community_transparency_chats FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE TABLE public.community_ai_state (
 id text PRIMARY KEY,
 paused boolean NOT NULL DEFAULT false,
 reason text,
 status integer,
 updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.community_ai_state TO service_role;
ALTER TABLE public.community_ai_state ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_only_ai_state ON public.community_ai_state FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE FUNCTION public.begin_community_chat(p_member uuid, p_lease uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r public.community_transparency_chats;
BEGIN
 INSERT INTO public.community_transparency_chats(member_id) VALUES(p_member) ON CONFLICT DO NOTHING;
 SELECT * INTO r FROM public.community_transparency_chats WHERE member_id=p_member FOR UPDATE;
 IF r.lease_until > now() THEN RAISE EXCEPTION 'chat_busy'; END IF;
 IF r.requests_day=CURRENT_DATE AND r.requests_today>=30 THEN RAISE EXCEPTION 'daily_limit'; END IF;
 UPDATE public.community_transparency_chats SET lease_id=p_lease, lease_until=now()+interval '10 minutes', requests_today=CASE WHEN requests_day=CURRENT_DATE THEN requests_today+1 ELSE 1 END, requests_day=CURRENT_DATE WHERE member_id=p_member;
 RETURN r.messages;
END; $$;
REVOKE ALL ON FUNCTION public.begin_community_chat(uuid,uuid) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.begin_community_chat(uuid,uuid) TO service_role;